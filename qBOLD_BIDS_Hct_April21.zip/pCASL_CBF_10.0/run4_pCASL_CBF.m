%% pCASL analysis script
% - CSF calculation by pCASL data analysis is performed for all subjects 
%   in folder which were not previosly processed.
% - CBF_finished.tif file is used as a flag to indicate processed patient data.
% - Required patient data: MPR, FLAIR, pCASL, PD.
% - Original program from Christine Preibisch.
% - Some parts have a copyright:
%   + Copyright (C) 2005 Wellcome Department of Imaging Neuroscience.
%   + Ze Wang @ TRC, CFN, Upenn 2004.
% - Major changes by Stephan Kaczmarz.

%% Dependencies

% - CP 11APR20: Matlab 2019b (tested)
% - SPM12
% - batch_segment
% - subfunctions in folder pCASL_CBF_10.0

%% Modifications

% - SK25MAI15
%   + Major changes: adapted script from PASL to pCASL.
%   + New file: calc_cbf_PVEcorr_philips

% - SK01JUN15
%   + Commented and structurized programs.
%   + Adaption from SPM8 to SPM12.
%   + Brain mask generation in segmentation.

% - SK02JUN15
%   + Implement coreg3.
%   + Include mean pCASL to realignment as its used to coreg MPR & PD
%   + Debug coreg.

% - SK03JUN15
%   + Debug CBF calculation by correcting PLD(slice) with GVE timing 
%     measurements
%   + Use brainmasked CBF images for further postprocessing
%   + Structurized Postprocesing

% - SK09JUN15
%   + Redefined path definition for patient measurements
%   + Matlab scripts on home folder, but patient data on local disc in order 
%     to accelerate the data analysis
%   + Correct multiple patient processing
%   + Correct 
%   + Integrated old normalization
%   + Initiate finished flag setting
%   + SPM12 modification: Replace spm_chi2_plot by spm_plot_convergence

% - SK10JUN15
%   + Debugging: File selection in Coreg1 & Coreg2
%   + Commented
%   + Debugging: Mistakes in CBF formula
%   + Extract some postprocessing to separate file: Mask application in 
%     highres after coreg to highres MPR

% - CHPSK10JUN15
%   + New additional Brainmask including CSF (GM & WM & CSF)
%   + Signal rescaling of PD & pCASL in order to match PD & pCASL signal 
%     intensity

% - SK12JUN15
%   + Store CBF-data in Lowres & Highres folders
%   + Signal rescaling of PD & pCASL moved: directly before CBF measurements 
%     to prevent saturation artifacts

% - SK17JUN15
%   + Introduce smoothing to PD
%   + Debug CBF calculation: PVE correction
%   + Copy all highres related data to highres folder

% - SK19JUN15
%   + Extensive debugging

% - SK22JUN15
%   + Generate Lowres Brainmasks by coreg segments instead of lowres segments 
%     in order to improve the masks

% - SK24JUN15
%   + Add statistics analysis CBF calc

% - SK26JUN15
%   + Clean up CBF calc

% - SK08JUL15
%   + Interpolation

% - SK09JUN15
%   + CBF: Add normalization choice option

% - SK16JUL15
%   + Clean up

% - SK13AUG15 
%   + Include difference map calculated on scanner

% - SK16OCT15
%   + Include patched pCASL files
%   + Add parameters to global Variables VAR to further automate processing

% - SK19OCT15
%   + Detect Sequence & set corresponding VAR variables

% - SK21OCT15
%   + Realign multiple PD's

% - SK20NOV15
%   + Bug fixes
%   + Comment voxel interpolation
%   + Get global var
%   + Involve all relevant files to depedencies folder

% - SK23NOV15
%   + Nifty files instead of Analyze
%   + Debug

% - SK26JAN16
%   + Auto detect PLD_0 by sequence name

% - SK18AUG16
%   + Added ss-ASL feature: Use M0 and segmented MPR from global pCASL

% - SK08FEB17
%   + Debugging ssASL processing

% - CPJUL2018
%   + turm all scripts to function
%   + clean up
%   + adapt for Valentin's qBOLD study
%
% - CPJAN2019
%   + adapt to data from MR-PET (Dicom fomat)
%   + further clean up
%
% - CPAPR2020
%   + adapt to BIDS input & multi condition mq-BOLD studies
%   + major revision and cleanup
%   + tested only basic CBF calculation funcitonalities
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   CP 11APR20: CAVE: 
%   + set_var.m & get_var.m still need to be fixed!!!
%   + partial volume correction needs to be implemented
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Future ideas

% - SK09JUN15
%   + FLAIR images could be included for improved segmentation.
%   + VAR.flag plot ueberall integrieren

% - SK08FEB17
%   + Clean up code
%   + Omit linux specific code, e.g. copy by console 'cp'
%   + Include Ilias PVE correction
%   + Save some HDD space: delete unnessary processing files
%   + Save some HDD space: save only necessary files, include flag for full save
%   + (Add option to save workspace)
%   + Look at MoCo: filtering instead of smoothing, no coreg?

function [SubjectDir, filelist] = run5_pCASL_CBF(SubjectDir, filelist, ...
                        subject_name, conditions, nconditions, pCASL_pars)

% -------------------------------------------------------------------------
% Set global variables for each subject and save to subject's folder
% --> VAR file in each subject's toplevel folder
%--------------------------------------------------------------------------
[VAR, filelist] = set_var_pCASL(SubjectDir, filelist, subject_name); 

% -------------------------------------------------------------------------
% PREPROCESSING
% -------------------------------------------------------------------------
%--------------------------------------------------------------------------
% Moco: Realign time series pCASL images to the first pCASL volume 
% (for all conditions)
%--------------------------------------------------------------------------
% --> vol 1 images realigned for all conditions, prefix 'rr'. 
% --> vol 2 images realigned for all conditions, prefix 'r'
% --> vol 2 images coregistered to vol 1, prefix 'rr'
%--------------------------------------------------------------------------
call_realign_pCASL_separate(SubjectDir, filelist, subject_name, ...
                                                       nconditions); 
        
%--------------------------------------------------------------------------
% M0 coreg 2 pCASL mean data (for all conditions)
% --> M0 coreg to pCASL in 'pCASL/M0' folder, prefix 'rmean'
%--------------------------------------------------------------------------
coreg_M0_2_pCASL(SubjectDir, subject_name, nconditions);
        
%--------------------------------------------------------------------------
% Smooth M0 (for all conditions)
%--------------------------------------------------------------------------
% --> Smoothed M0 in 'pCASL/M0' folder, prefix 's' --> prefix 'sr0'
smooth_M0(VAR, SubjectDir, subject_name, nconditions)

%--------------------------------------------------------------------------
% Smooth pCASL (for all conditions)
% --> Smoothed pCASL in 'pCASL' subfolders pCASL_realigned_vol1 & 2
% --> prefix 'srr'
%--------------------------------------------------------------------------
smooth_pCASL(VAR, SubjectDir, subject_name, nconditions) 

%--------------------------------------------------------------------------
% Copy T1w (MPR) data & segments to pCASL folder of 1st condition
% ---> one anatomical reference is sufficient, since pCASL data 
%      of all conditions are fully coregistered
%--------------------------------------------------------------------------
[SubjectDir, filelist] = copy_T1w_2_pCASL(SubjectDir, filelist, ...
                                          subject_name, conditions);        
                                         
%--------------------------------------------------------------------------
% Coreg anatomical data (T1w MPR) in 'pCASL/T1w' folder to pCASL 
% mean image --> prefix 'r'
%--------------------------------------------------------------------------
coreg_MPR_2_pCASL(SubjectDir, subject_name, conditions);

% -------------------------------------------------------------------------
% CBF CALCULATION
% -------------------------------------------------------------------------
% Calculate CBF maps in low pCASL resolution (native space)
% --> CBF maps saved in CBF_Lowres folder
%--------------------------------------------------------------------------
SubjectDir = call_calc_cbf(VAR, SubjectDir, subject_name, nconditions, ...
    pCASL_pars);

%--------------------------------------------------------------------------
% Coregister all conditions brain masekd CBF (CBF_3_BRmsk_CSF) mq-BOLD data
% ---> coregister low resolution T1w MPR (coregistered to pCASL data
%      to low resolution T1w MPR coregistered to T2-TE1 
%      (in qBOLD native space)
% CAVE: coregistered files are saved with prefix 'x' 
%--------------------------------------------------------------------------
[SubjectDir] = coreg_CBF_2_qBOLD_T1w(SubjectDir, subject_name, nconditions);

%--------------------------------------------------------------------------
% Copy CBF maps to top level of subject's condition folders
%--------------------------------------------------------------------------
copy_CBF_2_condition_dirs(SubjectDir, subject_name, nconditions);   

end