%% Set global VAR variables
% - Stephan Kaczmarz
% - 20OCT15

%% Required subscripts


%% Modifications
% - CP 09APR20
%   + adapt to BIDS & major cleanup

%% Main program

% -------------------------------------------------------------------------
% INITIALIZE
% -------------------------------------------------------------------------

function [VAR, filelist] = set_var_pCASL(SubjectDir, filelist, subject_name)
    
    % Internal flag_overwrite_VAR;
    flag_overwrite_VAR = 1;
    % Internal flag_display_dialog;
    flag_display_dialog = 0;

    % ---------------------------------------------------------------------
	% SET PATHS
	% ---------------------------------------------------------------------

	% Print status
	fprintf('Started variable setting of Subject %s\n', subject_name);
    
    % Save variables to file for later reload
    name_global_var = 'Variables.mat';

	% ---------------------------------------------------------------------
	% CHECK for EXISTING FILES
	% ---------------------------------------------------------------------

    % Check if VAR file already exists
	% Get VAR path
    filelist.pCASL_VAR = fullfile(SubjectDir.output, name_global_var);

	% Check for VAR file
	if exist(filelist.pCASL_VAR, 'file') == 2
    	fprintf('    VAR file already exists.\n')

    	% Use same choise for all folders. Check if questions was 
     	% already answered
        if flag_display_dialog
          	% If file exists: Ask before overwrite existing one
           	button = questdlg('Existing VAR file found!', ...
                    'VAR file options', 'Create new file', ...
                    'Use existing one', 'Create new file');
         	flag_display_dialog = 0;
          	% Analyze answer
           	switch button
            	case 'Create new file'
                	flag_overwrite_VAR = 1;
                 	flag_write_VAR = 1;
              	case 'Use existing one'
                 	flag_overwrite_VAR = 0;
                 	flag_write_VAR = 0;
            end
     	else
                flag_write_VAR = flag_overwrite_VAR;
        end % if flag_display_dialog
    else
    	flag_write_VAR = 1; % No file --> set flag to create new one
	end

	% -----------------------------------------------------------------
	% SET VAR
	% -----------------------------------------------------------------

    % Check if VAR shall be set
	if flag_write_VAR

     	% Print status
       	fprintf('    Setting global variables:\n')

     	% -----------------------------------------------------------------
      	% Image Display VAR
      	% -----------------------------------------------------------------

    	% Suppress image display
      	VAR.flag_suppress_display = 0;

       	% -----------------------------------------------------------------
       	% Image Loading VAR
      	% -----------------------------------------------------------------

        % Use deltaM manually calculated or by the scanner
       	VAR.flag_deltaM_scanner = 0; % 0: does not use deltaM from scanner
      	% Print status
      	if VAR.flag_deltaM_scanner
         	fprintf('Using delta M calculated by the scanner.\n');
        else
          	fprintf('Using raw pCASL data of scanner to calculate delta M within this program.\n');
        end

      	% Force program to use PD instead of M0 in case of patched sequences
      	VAR.flag_load_patched_PD = 0; % 0: use M0
      	if VAR.flag_load_patched_PD
          	fprintf('Loading PD for patched pCASL is forced.\n')
        else
           	fprintf('Loading PD for patched pCASL is not forced.\n')
        end

     	% -----------------------------------------------------------------
        % pCASL VAR
       	% -----------------------------------------------------------------

      	% Post label delay set at the scanner [ms].
       	VAR.PLD_0 = 1800;
      	% Print status
      	fprintf('Post label delay is expected to be set to %i ms.\n',...
                VAR.PLD_0);

       	% Label duration at measurement
       	VAR.tao = 1800; % Label duration in ms, following advice from [Alsop15]
       	% Print status
      	fprintf('Label duration is expected to be set to %i ms.\n', ...
                VAR.tao);

       	% Set threshold for mask generation by segments
       	VAR.th_mask = 0.2;
     	% Print status
    	fprintf('CBF mask generation TH is set to %f.\n', VAR.th_mask);

       	% Switch gain correction: PD & pCASL are normalized by gain values. 
       	% Relevant if dotscaling was deactivated
       	VAR.switch_gain_correction = 0;
      	% Print status
      	fprintf('CBF Gain correction flag is set to be %i.\n', ...
                VAR.switch_gain_correction);

      	% Norm factor application between pCASL & PD. 
      	% Normalized PD & pCASL by median
       	VAR.switch_norm_factor_post = 0;
       	% Print status
       	fprintf('CBF median normalization flag is set to be %i.\n', ...
                VAR.switch_norm_factor_post);

    	% Choose normalization either by PD or first pCASL volume
     	%   0: pCASL Norm
        %   1: PD Norm
    	VAR.flag_norm_M0 = 1;
       	% Print status
      	if VAR.flag_norm_M0
         	fprintf('CBF calculation will use M0 for normalization.\n');
        else
           	fprintf('CBF calculation will use first pCASL image for normalization.\n');
        end

      	% Number of omitted slices due to moco artifacts in top/bottom slices.
       	VAR.cutoff_slices = 2;
     	% Print status
     	fprintf('Due to moco artifacts, %i slices will be cut off at top and bottom of CBF maps.\n', ...
                VAR.cutoff_slices);

      	% CBF map display and cut off threshold for saved data.
      	VAR.th_display_CBF = 100;
       	VAR.th_cutoff_CBF = 500;
      	% Print status
        fprintf('CBF maps will be displayed up to threshold of %i ml/100g/min.\n', ...
                VAR.th_display_CBF);
       	fprintf('CBF maps will be saved up to threshold of %i ml/100g/min.\n', ...
                VAR.th_cutoff_CBF);

       	% Show extra plots
        VAR.flag_plot = 0;
       	% Print status
        fprintf('    Flag plot is set to be %i.\n', VAR.flag_plot);

      	% pCASL Processing settings
       	VAR.alpha = 0.85; % label efficiency for pCASL [Alsop15]

    	% -------------------------------------------------------------
       	% Smoothing VAR
      	% -------------------------------------------------------------

     	% Smoothing kernel of M0 smooting
     	VAR.fwhm_smooth_M0 = [5];
      	% Smoothing kernel of CBF smooting
     	VAR.fwhm_smooth_CBF = [5];
      	% Smoothing pCASL Label and Control before CBF calculation
       	VAR.flag_smooth_pCASL = 1;
       	VAR.fwhm_smooth_pCASL = [5];

       	% -------------------------------------------------------------
     	% Save results
       	% -------------------------------------------------------------

    	% Save variables to file for later reload
        save(filelist.pCASL_VAR, 'VAR');
        % Print status
        fprintf('Saved global variables to %s\n', filelist.pCASL_VAR);

    else
        fprintf('Existing VAR file will be used.\n');
	end % if flag_write_VAR
end