%% Coregistration of MPR 2 pCASL
% - Original program from Christine Preibisch.
% - Started in SPM2.

%% Required subscripts

% - SPM12


%% Modifications

% - SK22MAI15
%   + Deleted old, unused commented code

% - SK01JUN15
%   + Commented and structurized
%   + Deleted old, unused commented code

% - CP 09APR20
%   + adapt to BIDS & major cleanup


%% Main program
function coreg_MPR_2_pCASL(SubjectDir, subject_name, nconditions)

    % ------------------------------------------------------------------------
    % INITIALIZE
    % ------------------------------------------------------------------------

    % Print status
    fprintf('Coregistering T1w MPR data to pCASL data for subject %s\n',...
        subject_name);

    % Load defaults
    global defaults;
    spm_defaults;
    flags = defaults.coreg;

    % Flags to pass to routine to create resliced images
    % (spm_reslice)
    resFlags = struct(...
        'interp', flags.write.interp,...       % 1: trilinear interpolation
        'wrap', flags.write.wrap,...           % wrapping info (ignore...)
        'mask', flags.write.mask,...           % masking (see spm_reslice)
        'which',1,...                         % write reslice time series 
        'mean',0);                            % do not write mean image


    % ---------------------------------------------------------------------
    % COREGISTRATION
    % ---------------------------------------------------------------------


	% ---------------------------------------------------------------------
	% Set source and target
	% ---------------------------------------------------------------------

	% PG - Tar(G)et image, NEVER CHANGED
	% PF - Source image, transformed to match PG
	% PO - (O)ther images, originally realigned to PF and transformed with PF


  	% TARGET: Mean pCASL vol 1 (same for all conditions)
   	ncd = 1;
   	PG = spm_select('FPList',SubjectDir.condition(ncd).pCASL.toplevel,...
            '^meano.*\_1.nii$');
  	ncd = ncd+1;
	while isempty(PG) && ncd <= nconditions % look for mean in other 
                                            % condition directories
      	PG = spm_select('FPList',SubjectDir.condition(2).pCASL.toplevel,...
                '^meano.*\_1.nii$');
     	ncd = ncd+1;
	end         
    VG = spm_vol(PG);

    % SOURCE: T1w MPR
    PF=spm_select('FPList',SubjectDir.condition(1).pCASL.T1w,...
        '^sub.*\.nii$');
    PF=PF(1,:);
    VF = spm_vol(PF);
    
    % Other Images: all T1w segments and BrMsks 
    % Get files in this directory
    PO = spm_select('FPList', SubjectDir.condition(1).pCASL.T1w,...
        '^c.*\.nii$');

    %PO = PF; --> this if there are no 'other' images
	if isempty(PO)
        PO=PF;
    else
      	PO = char(PF,PO);
    end

    % ---------------------------------------------------------------------
	% Get coregistration parameters
	% ---------------------------------------------------------------------

	% This method from spm_coreg_ui.m
	% Get coregistration parameters
	x  = spm_coreg(VG, VF,flags.estimate);

	% Get the transformation to be applied with parameters 'x'
	M  = inv(spm_matrix(x));

	% Transform the mean image
	% Spm_get_space(deblank(PG),M);
	% In MM we put the transformations for the 'other' images
	MM = zeros(4,4,size(PO,1));
   	for j=1:size(PO,1)
       	%get the transformation matrix for every image
       	MM(:,:,j) = spm_get_space(deblank(PO(j,:)));
    end
	for j=1:size(PO,1)
     	%write the transformation applied to every image
      	%filename: deblank(PO(j,:))
     	spm_get_space(deblank(PO(j,:)), M*MM(:,:,j));
	end

	% ---------------------------------------------------------------------
	% Apply coregistration 
	% ---------------------------------------------------------------------

	P = char(PG, PO);
	spm_reslice(P,resFlags);

    % Print status
    fprintf('Finished coreg of T1w data to pCASL images for subject %s\n',...
        subject_name);
end