%% Call calculate CBF for all subjects
% - Original program from Christine Preibisch.
% - Started in SPM2.

%% Required subscripts

% - SPM12
% - calc_cbf_PVEcorr_philips
%   + get_deltaM
%   + calc_GMcbf


%% Modifications

% - SK22MAI15
%   + Major changes, changed CBF calculation from PASL to pCASL
%   + Commented and structurized

% - SK01JUN15
%   + Commented and structurized
%   + Deleted old, unused commented code

% - CP


%% Main program
function SubjectDir = call_calc_cbf(VAR, SubjectDir, subject_name, ...
                                                nconditions, pCASL_pars)
    % ---------------------------------------------------------------------
    % RUN CBF CALCULATION
    % ---------------------------------------------------------------------
    % Print status
    fprintf('\nCalculate CBF for all conditions of subject %s....\n',...
        subject_name);

	% Choose pCASL files for processing
	if VAR.flag_smooth_pCASL
        searchstring_pCASL = '^srr.*\.nii$';
	else
        searchstring_pCASL = '^rr.*\.nii$';
	end
    
    %Set path to T1w anatomy in 1st condition pCASL subfolder
    dir_anatomy = SubjectDir.condition(1).pCASL.T1w;
    
    for ncd = 1:nconditions
        % Use dir of pCASL images to select coregistered files
        dir_pCASL = SubjectDir.condition(ncd).pCASL.toplevel;
        dir_pCASL_vol1 = fullfile(dir_pCASL, 'pCASL_realigned_vol1');
        dir_pCASL_vol2 = fullfile(dir_pCASL, 'pCASL_realigned_vol2');
        % Get path to fully realigend and coregisteres pCASL data
        filelist_pCASL_vol1 = spm_select('FPList', dir_pCASL_vol1, ...
                                                    searchstring_pCASL);
        filelist_pCASL_vol2 = spm_select('FPList', dir_pCASL_vol2, ...
                                                    searchstring_pCASL);                                               
        % Display status
        fprintf('\Loading realigned pCASL data from \n%s\n%s', ...
                                dir_pCASL_vol1, dir_pCASL_vol2);

        % M0
        dir_M0 = fullfile(dir_pCASL, 'M0');
        filelist_M0 = spm_select('FPList',dir_M0,'^sro.*\.nii$');  
        % Display status
        fprintf('\Loading coregistered smoothed coreg M0 data from file \n%s\n',...
            filelist_M0)
        
        % set subjects condition dir
        dir_condition = SubjectDir.condition(ncd).toplevel;
        
      	% Call CBF calculation for each condition
        SubjectDir = calc_cbf(VAR, SubjectDir, dir_condition, dir_anatomy, ...
          	filelist_pCASL_vol1, filelist_pCASL_vol2, filelist_M0, ...
            subject_name, ncd, pCASL_pars);
    end %for ncd = 1:nconditions
end