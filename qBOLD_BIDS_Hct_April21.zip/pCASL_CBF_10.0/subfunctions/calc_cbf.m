%% Calculate CBF 
% Calculates CBF from an pCASL time series
% Original program from Christine Preibisch 07MAI09
% Major changes by Stephan Kaczmarz 2015

%% Required subscripts

% - SPM12


%% Modifications

% - CHP12JUN09
%   + Output-file copies header of input-File

% - CHP11SEP09
%   + include correction for partial volume effects PVE

% - CHP20JAN11
%   + Use spm input/output functions

% - SK22MAI15
%   + Major changes, changed CBF calculation from PASL to pCASL
%   + Commented and structurized

% - SK01JUN15
%   + Commented and structurized
%   + Deleted old, unused commented code

% - SK03JUN15
%   + Debug CBF calculation by correcting PLD(slice) with GVE timing measurements
%   + Use brainmasked CBF images for further postprocessing
%   + Structurized Postprocesing

% - SK10JUN15
%   + Commented
%   + Debugging: Mistakes in CBF formula
%   + Extract postprocessing to separate file: Mask application in highres after coreg to highres MPR

% - CHPSK10JUN15
%   + New additional Brainmask including CSF (GM & WM & CSF)

% - SK11JUN15
%   + PVE correction th application
%   + Save applied masks
%   + CBF results folder

% - SK15JUN15
%   + Save parameters as dictionary

% - SK17JUN15
%   + Debugging PVE correction: Load CBF(GM), do not apply additional mask

% - SK24JUN15
%   + Add statistics analysis CBF calc

% - SK26JUN15
%   + Clean up, extract some functions to shorten sourcecode
%   + Include segment selection

% - SK09JUN15
%   + Display Q
%   + Add normalization choice option

% - SK16JUL15
%   + Added projection plots

% - SK22OCT15
%   + PLD for 3D sequences


%% PAPER REFERENCES

% - CHP11SEP09
%   + [Johnson05] PVE correction based on Johnson et al. 
%                           - Radiology 234:851-859(2005)

% - SK22MAI15
%   + [Alsop15] CBF(pCASL) based on Alsop et al. - MRM 73:102-116(2015)

% - CP 31AUG18
%   + facilitate multiple conditions and remove unnecessary processings

% - CP09APR20
%   + adapt to BIDS structure and major cleanup
%   + remove outdated partial volume correction by Johnson et al.

%% Main program
% Quantitative perfusion calculation 

function SubjectDir = calc_cbf(VAR, SubjectDir, dir_condition, dir_anatomy, ...
                filelist_pCASL_vol1, filelist_pCASL_vol2, filelist_M0, ...
                subject_name, ncd, pCASL_pars)
 
    % ---------------------------------------------------------------------
    % SUPRRESS DISPLAY - Yes / No?
    % ---------------------------------------------------------------------
    if VAR.flag_suppress_display
        % Print status
        fprintf('Image display is suppressed.\n');
        % Apply display suppression
        set(0, 'DefaultFigureVisible', 'off')
    end

    % ---------------------------------------------------------------------
    % DEFINE VARIABLES
    % ---------------------------------------------------------------------

    % Get and save Timings 
    if strcmp(pCASL_pars.Manufacturer, 'Philips')
        % Time interval between the readout of s neighboring slices [ms],
        % (needs to be measured with GVE)
        VAR.deltat_slice = 35.2; 
    elseif strcmp(pCASL_pars.Manufacturer, 'Siemens')
        % needs to be defined / for a first try
        VAR.deltat_slice = 35.2; 
    end

    % Number of cutted of slices on bottom
    cut_offslices_bottom = VAR.cutoff_slices;
    % Number of cutted of slices on top
    cut_offslices_top = VAR.cutoff_slices;

    % Folder where to save the statistics .tif files
    folder_statistics = 'Statistics';

    % Plotted scaling maximum of relative label differences
    plot_max_reldiff_labels = 10;
    % Plotted absolute negative deltaM values
    plot_max_negatives = 0.015;


    % ---------------------------------------------------------------------
    % DEFINE COMMON CONSTANTS
    % ---------------------------------------------------------------------

    % Konstanten aus der Literatur zur quantitativen Berechnung 
    VAR.T1b = 1650; % T1 Zeit von Blut (3T) in msec [Alsop15]
    VAR.lambda = 0.9; % blood-brain partition coefficient [0.9 mL/g] [Alsop15]
    VAR.T1GM = 1500; % T1 Zeit von GM (3T) in msec
    %T1WM = 832; % T1 Zeit von WM (3T) in msec
    %T2effWM = 47; % T2* Zeit von WM (3T) in msec


    % ------------------------------------------------------------------------
    % LOAD IMAGES
    % ------------------------------------------------------------------------

    % Load PD images
    V = spm_vol(filelist_M0);
    [PD, ~] = spm_read_vols(V);
	if strcmp(pCASL_pars.Manufacturer, 'Philips')
     	% According to Dick Kooijman:
     	% dicom-tag 0028,1053 (�rescale slope�) can be wrong 
     	%       ---> divide by rescale slope
      	% dicon-tag 2005,100E (�scale slope�) should be right
      	%       ---> multiply with scale slope
     	%CP 10APR20: first attempt of scaling, seems to work,
        % but needs more thorough testing
       	PD = PD * pCASL_pars.ScaleSlope;
%         PD = PD / pCASL_pars.RescaleSlope;    
        % CAVE: pCASL time series data (vol1, vol2) need identical scaling
	elseif strcmp(pCASL_pars.Manufacturer, 'Siemens')
        % CP 11APR20: No scaling parameters available from json file
	end

    % Read motion corrected PASL data: 
    [deltaM, deltaM_postproc, vol1, GMseg, WMseg, CSFseg, BrMsk, BrMsk_CSF, ...
        direct_read, nslices, fig_no, factor_pCASL] = get_deltaM(VAR, ...
        filelist_pCASL_vol1, filelist_pCASL_vol2, ncd, subject_name, ...
        folder_statistics, plot_max_reldiff_labels, dir_anatomy, pCASL_pars);

    % ------------------------------------------------------------------------
    % MASKS
    % ------------------------------------------------------------------------

    % Create 75% GM mask
    GMMsk = GMseg > VAR.th_mask;
    % Create 75% WM mask  
    WMMsk = WMseg > VAR.th_mask;
    % Show segments
    fig_no = fig_show (fig_no, GMseg, 'hot', ncd, subject_name, 'Segments - GM', ...
                                        folder_statistics, 1, direct_read);
    fig_no = fig_show (fig_no, WMseg, 'hot', ncd, subject_name, 'Segments - WM', ...
                                        folder_statistics, 1, direct_read);


    % ------------------------------------------------------------------------
    % STATISTICS PD
    % ------------------------------------------------------------------------

    [PD_med, PD_mean, PD_std, x] = statistics_median(PD .* BrMsk);
    figure(fig_no); errorbar(PD_mean, PD_std); legend('Mean & Std of PD'); 
    xlabel('Slice number'); ylabel('Intensity'); 
    title_str = sprintf('SB %s cond %d: PD - Slice selective Mean & Std - BrMsk applied',...
        subject_name, ncd);
    title(title_str);
    fig_no = fig_no + 1;
    check_folder(fullfile(direct_read, folder_statistics));
    outfile=fullfile(fullfile(direct_read, folder_statistics),'PD_Statistics.tif');
    saveas(gcf,outfile);

%     % Projection display
%     fig_no = plot_projection(PD, fig_no, fullfile(direct_read, folder_statistics),...
%                                 'PD', ncd);


    % ------------------------------------------------------------------------
    % DIRECTORIES
    % ------------------------------------------------------------------------

    % Choose directory to save: New CBF folder
    direct_write = fullfile(dir_condition, 'CBF_Lowres');
    SubjectDir.condition(ncd).pCASL.CBF_Lowres = direct_write;
    % Make directory
    if ~exist(direct_write, 'dir')
        mkdir(direct_write);
        fprintf('    Creating directory %s\n', direct_write);
    end
    % Choose directory to save applied masks
    direct_write_mask = fullfile(direct_write, 'masks');
    % Make directory
    if ~exist(direct_write_mask, 'dir')
        mkdir(direct_write_mask);
        fprintf('    Creating directory %s\n', direct_write_mask);
    end


    % ------------------------------------------------------------------------
    % GAIN CORRECTION PD
    % ------------------------------------------------------------------------

%     if VAR.switch_gain_correction || VAR.flag_ssASL
%         % Display status
%         fprintf('    Applying gain correction to PD images\n');
%         % Get previously saved gain correction values
%         [RI, RS, SS] = VAR.gain_PD{1,:};
%         % Calculate whole image median pre Gain correction
%         median_PD_old = median_flat_nonzero(PD .* BrMsk, 1);
%         % Apply Gain correction
%         %PD = (PD * RS + RI) / (RS * SS);
%         factor_PD = RS / (RS * SS);
%         % Calculate whole image median post Gain correction
%         median_PD_new = median_flat_nonzero(PD * factor_PD .* BrMsk, 1);
%         % Display status
%         fprintf('        median(PD): %.1f --> %.1f\n', median_PD_old, median_PD_new);
%      else
%         factor_PD = 1;
%      end

    if strcmp(pCASL_pars.Manufacturer, 'Philips')
        factor_PD = 1;
    elseif strcmp(pCASL_pars.Manufacturer, 'Siemens')
        factor_PD = 10; % was 10 for directly imported Dicom images       
    end                 % should ideally be replaced by a proper scaling
    % ---------------------------------------------------------------------
    % Choose CBF normalization
    % ---------------------------------------------------------------------

    if VAR.flag_norm_M0
        % Dispaly status
        fprintf('    Using normalization by M0.\n');
        % Use PD for normalization
        norm = PD;
    else
        % Display status
        fprintf('    Using normalization by pCASL volume 1.\n');
        % Use PD for normalization
        norm = vol1;
    end


    % ------------------------------------------------------------------------
    % SAFE DELTA M
    % ------------------------------------------------------------------------

    % Make and save DELTAM
    % Choose data type double
    V.dt = [64 0];
    write_vol(deltaM_postproc, V, 'DeltaM_postproc.nii', direct_write);

    % ------------------------------------------------------------------------
    % CBF CALCULATION
    % ------------------------------------------------------------------------

    % Calculate slice dependent post label duration PLD
    % If 3D seuqnce is used, PLD is not slice dependent
    PLD(1) = VAR.PLD_0;
    for n=2:nslices
        PLD(n) = PLD(n-1)+ VAR.deltat_slice;
    end

    %factor_PD = 1/(1-exp(-TR/T1GM))

    % CBF calculation in ml/100g/min
    % Scalefactor 6000 due to unit conversions
    % From Alsop2015
    for n=1:nslices
        % Constant 1
        C1 = 6000 * VAR.lambda * exp(PLD(n)/(VAR.T1b)); 
        % Constant 2, T1b converted from ms to s
        C2 = 2 * VAR.alpha * (VAR.T1b / 1000) * (1 - exp(-VAR.tao/VAR.T1b)); 
        % CBF Calculation
        CBF(:,:,n) = C1/C2*deltaM(:,:,n)./(norm(:,:,n)+eps)*(factor_pCASL/factor_PD); 
        Q(:,:,n) = deltaM(:,:,n)./(norm(:,:,n)+eps)*factor_pCASL/factor_PD;
    end


    % ---------------------------------------------------------------------
    % NORMALIZATION OF PD & PCASL
    % ---------------------------------------------------------------------

    % Apply norm factor to CBF
    if VAR.switch_norm_factor_post
        % Calculate PD median
        median_PD = median_flat_nonzero(PD .* GMMsk, 1);
        % Calculate deltaM median
        median_vol1 = median_flat_nonzero(vol1 .* GMMsk, 1);
        % Calculate normalization factor
        norm_factor = median_PD/median_vol1;
        % Apply norm factor
        CBF = CBF * norm_factor;    
        % Dispaly status
        fprintf('Applying normalization factor of %.2f to CBF.\n', norm_factor);
    end


    % ------------------------------------------------------------------------
    % BASIC CBF PROCESSING
    % ------------------------------------------------------------------------
    % Saved nii images are not brain masked in order not to cut off brain
    % regions in this low resolution regime.

    % Choose double filetype
    V.dt = [64 0];

    % -------------------------
    % DISPLAY RAW IMAGE
    % -------------------------
    % Display CBF-DATA
    fig_no = fig_show (fig_no, CBF, 1, ncd, subject_name, 'CBF Raw', ...
        folder_statistics, 0, '', [0; 3*mean(CBF(GMMsk))]);
    % Make and save nifti file of raw CBF-DATA
    write_vol(CBF, V, 'CBF_0_raw.nii', direct_write)


    % -------------------------
    % CUT OFF SLICES
    % -------------------------
    if cut_offslices_bottom ~= 0
        % Dispaly status
        fprintf('    Cutting off %i slices on bottom.\n', cut_offslices_bottom);
        % Set bottom slices to zero
        CBF(:,:,1:(cut_offslices_bottom)) = 0;
        WMseg(:,:,1:(cut_offslices_bottom)) = 0;
        GMseg(:,:,1:(cut_offslices_bottom)) = 0;
        BrMsk(:,:,1:(cut_offslices_bottom)) = 0;
        BrMsk_CSF(:,:,1:(cut_offslices_bottom)) = 0;
    end
    if cut_offslices_top ~= 0
        % Dispaly status
        fprintf('    Cutting off %i slices on top.\n', cut_offslices_top);
        % Set top slices to zero
        CBF(:,:,(end - cut_offslices_top +1):end) = 0;
        WMseg(:,:,(end - cut_offslices_top +1):end) = 0;
        GMseg(:,:,(end - cut_offslices_top +1):end) = 0;
        BrMsk(:,:,(end - cut_offslices_top +1):end) = 0;
        BrMsk_CSF(:,:,(end - cut_offslices_top +1):end) = 0;
    end


    % -------------------------
    % IMAGE > 0
    % -------------------------
    % Minimum Perfusion value = 0!
    % Generate non negative mask and apply it to CBF-data
    CBF_pos_mask = CBF > 0;
    CBF = CBF.*CBF_pos_mask;
    % Generate mask of negative CBF values
    CBF_neg_mask = CBF < 0;
    % Print status
    fprintf('Thresholded %i negative voxels.\n', sum(sum(sum(CBF_neg_mask))));
    % Make and save nifti file of positive CBF-DATA
    write_vol(CBF, V, 'CBF_1_positive.nii', direct_write)
    % Save mask
    write_vol(CBF_pos_mask, V, 'mask_CBF_1_positive.nii', direct_write_mask)


    % -------------------------
    % THRESHOLDING
    % -------------------------
    if mean(CBF(GMMsk)) > VAR.th_cutoff_CBF
        CBFth_mask = CBF<5.0*mean(CBF(GMMsk));
        CBF_th = CBF.*CBFth_mask;
    else       
        CBFth_mask = CBF<VAR.th_cutoff_CBF;
        CBF_th = CBF.*CBFth_mask;
    end
    % Make and save nifti file of th CBF-DATA
    V.dt = [64 0];
    write_vol(CBF_th, V, 'CBF_2_th.nii', direct_write)
    % Save mask
    write_vol(CBFth_mask, V, 'mask_CBF_2_th.nii', direct_write_mask)

    % -------------------------
    % Extended BrMsk (WM, GM, CSF)
    % -------------------------
    % Select only voxels within the brain by SPM MPR based segmentation
    CBF_BrMsk_CSF = CBF_th.*BrMsk_CSF;
    % Make and save Brainmask applied CBF-DATA
    V.dt = [64 0];
    write_vol(CBF_BrMsk_CSF, V, 'CBF_3_BRmsk_CSF.nii', direct_write)
    % Save mask
    write_vol(BrMsk_CSF, V, 'mask_CBF_3_BRmsk_CSF.nii', direct_write_mask)


    % ------------------------------------------------------------------------
    % Save VAR
    % ------------------------------------------------------------------------
    save_var_pCASL(VAR, SubjectDir.condition(ncd).pCASL.toplevel) ;
end

%% Delta M and SNR calculation
% Use moco pCASL files to calculate differences with & without labeling
function [deltaM, deltaM_postproc, vol1_mean, GMseg, WMseg, CSFseg, BrMsk,  ...
        BrMsk_CSF, direct_read, nslices, fig_no, factor_pCASL] = get_deltaM(...
        VAR, filelist_pCASL_vol1, filelist_pCASL_vol2, ncd, subject_name, ...
        folder_statistics, plot_max_reldiff_labels, dir_anatomy, pCASL_pars)

    % ---------------------------------------------------------------------
    % LOAD IMAGE INFO
    % ---------------------------------------------------------------------
    direct_read = fileparts(filelist_pCASL_vol1(1,:));
    % Read motion corrected PASL data 
    fileprop1 = size(filelist_pCASL_vol1,1);
    fileprop2 = size(filelist_pCASL_vol2,1);

    % Check number of volumes
    if fileprop1 == fileprop2
        nvols = fileprop1;
    else
        fprintf('\n\n ERROR: Number of volumes does not agree between series 1 and 2!!!\n');
        fprintf('PLEASE RETRY!!!\n\n');
    end


    % ---------------------------------------------------------------------
    % LOAD PCASL IMAGES
    % ---------------------------------------------------------------------

    % Get SPM volume
    V1 = spm_vol(filelist_pCASL_vol1);
    V2 = spm_vol(filelist_pCASL_vol2);
        % FORMAT V = spm_vol(P)
        % P - a matrix of filenames.
        % V - a vector of structures containing image volume information.
        % The elements of the structures are:
        %       V.fname - the filename of the image.
        %       V.dim   - the x, y and z dimensions of the volume
        %       V.dt    - A 1x2 array.  First element is datatype (see spm_type).
        %                 The second is 1 or 0 depending on the endian-ness.
        %       V.mat   - a 4x4 affine transformation matrix mapping from
        %                 voxel coordinates to real world coordinates.
        %       V.pinfo - plane info for each plane of the volume.
        %              V.pinfo(1,:) - scale for each plane
        %              V.pinfo(2,:) - offset for each plane
        %                 The true voxel intensities of the jth image are given
        %                 by: val*V.pinfo(1,j) + V.pinfo(2,j)
        %              V.pinfo(3,:) - offset into image (in bytes).
        %                 If the size of pinfo is 3x1, then the volume is assumed
        %                 to be contiguous and each plane has the same scalefactor
        %                 and offset.

    % Read volume
    % Read in entire image volumes
        % FORMAT [Y,XYZ] = spm_read_vols(V,mask)
        % V    - vector of mapped image volumes to read in (from spm_vol)
        % mask - implicit zero mask?
        % Y    - 4D matrix of image data, fourth dimension indexes images
        % XYZ  - 3xn matrix of XYZ locations returned
    [vol1, ~] = spm_read_vols(V1);
    [vol2, ~] = spm_read_vols(V2);
      
	if strcmp(pCASL_pars.Manufacturer, 'Philips')
     	% According to Dick Kooijman:
     	% dicom-tag 0028,1053 (�rescale slope�) can be wrong 
     	%       ---> divide by rescale slope
      	% dicon-tag 2005,100E (�scale slope�) should be right
      	%       ---> multiply with scale slope
     	%CP 10APR20: first attempt of scaling, seems to work,
        % but needs more thorough testing
        vol1 = vol1 * pCASL_pars.ScaleSlope;
%       vol1 = vol1 / pCASL_pars.RescaleSlope; 
        vol2 = vol2 * pCASL_pars.ScaleSlope;
%       vol2 = vol2 / pCASL_pars.RescaleSlope; 
        % CAVE: MO data need identical scaling
	elseif strcmp(pCASL_pars.Manufacturer, 'Siemens')
        % CP 11APR20: No scaling parameters available from json file
	end
    
    % Get header information
    fname = filelist_pCASL_vol1(1,:);
    [hdr, ~] = spm_read_hdr(fname);
        % Read (SPM customised) Analyze header
        % FORMAT [hdr,otherendian] = spm_read_hdr(fname)
        % fname       - .hdr filename
        % hdr         - structure containing Analyze header
        % otherendian - byte swapping necessary flag

    % Get dimensions
    nx = hdr.dime.dim(2);
    ny = hdr.dime.dim(3);
    nslices = hdr.dime.dim(4);

    % ------------------------------------------------------------------------
    % GAIN CORRECTION PCASL
    % ------------------------------------------------------------------------
    factor_pCASL = 1;

    % ------------------------------------------------------------------------
    % CALCULATE DIFFERENCE IMAGES
    % ------------------------------------------------------------------------

    % Iterate over all volumes and calculate difference images
    difference = zeros(nx,ny,nslices,nvols);
    for i=1:nvols
        difference(:,:,:,i) = vol1(:,:,:,i)-vol2(:,:,:,i);
    end

    % Calculate mean images
    vol1_mean = mean(vol1,4);
    vol2_mean = mean(vol2,4);
    vol1_std = std(vol1, 1, 4);
    vol2_std = std(vol2, 1, 4);

    % ------------------------------------------------------------------------
    % LOAD MASKS
    % ------------------------------------------------------------------------

    % Select segments by names
    segment_names = {'rc1s'; 'rc2s'; 'rc3s'};
    % Display status
    fprintf('Using low resolution segments');

    % Read GM segment for PVE-correction (mask from segmented MPRAGE)
    searchstring = ['^' segment_names{1} '.*\.nii$'];
    filename = spm_select('FPList',dir_anatomy,searchstring);
    V = spm_vol(filename);
    [GMseg,~] = spm_read_vols(V);
    GMmask = GMseg > VAR.th_mask;

    % Read WM segment for PVE-correction (mask from segmented MPRAGE)
    searchstring = ['^' segment_names{2} '.*\.nii$'];
    filename = spm_select('FPList',dir_anatomy,searchstring);
    V = spm_vol(filename);
    [WMseg,~] = spm_read_vols(V);
    WMmask = WMseg > VAR.th_mask;

    % Read CSF segment for PVE-correction (mask from segmented MPRAGE)
    searchstring = ['^' segment_names{3} '.*\.nii$'];
    filename = spm_select('FPList',dir_anatomy,searchstring);
    V = spm_vol(filename);
    [CSFseg,~] = spm_read_vols(V);

    %Read Brain Mask for PVE-correction     
    searchstring = '^rcBrMsk.nii$';
    filename = spm_select('FPList',dir_anatomy,searchstring);
    V = spm_vol(filename);
    [BrMsk,~] = spm_read_vols(V);
    BrMsk = BrMsk > 0.5;
    
    %Read Brain Mask incl. CSF for PVE-correction     
    searchstring = '^rcBrMsk_CSF.*\.nii$';
    filename = spm_select('FPList',dir_anatomy,searchstring);
    V = spm_vol(filename);
    [BrMsk_CSF,~] = spm_read_vols(V);
    BrMsk_CSF = BrMsk_CSF> 0.5;

    % ---------------------------------------------------------------------
    % DELTA M CALCULATION
    % ---------------------------------------------------------------------

    % Average over all volumes
    deltaM = mean(difference,4);
    deltaM_std = std(difference, 1, 4);

    % Get NANs
    mask_deltaM_nan = isnan(deltaM);
    deltaM_nonan = deltaM;
    deltaM_nonan(mask_deltaM_nan) = 1;

    fig_no = 1;

    % Calculate relative difference map
    avg_diff_rel = 100*(deltaM ./ vol1_mean + eps) .* BrMsk;
    % Nan to num
    mask_nan = isnan(avg_diff_rel);
    avg_diff_rel(mask_nan) = 0;

    % Calculate relative difference map with GM mask
    GMmask = GMseg > VAR.th_mask;
    avg_diff_rel_GM = 100*(deltaM ./ vol1_mean + eps) .* GMmask;
    % Nan to num
    mask_nan_GM = isnan(avg_diff_rel_GM);
    avg_diff_rel_GM(mask_nan_GM) = 0;

    % Calculate relative difference map with GM mask
    WMmask = WMseg > VAR.th_mask;
    avg_diff_rel_WM = 100*(deltaM ./ vol1_mean + eps) .* WMmask;
    % Nan to num
    mask_nan_WM = isnan(avg_diff_rel_WM);
    avg_diff_rel_WM(mask_nan_WM) = 0;

    % Plot results
    % Switch plot flag on and off
    if VAR.flag_plot && VAR.flag_deltaM_scanner == 0
        fig_no = fig_show (fig_no, vol1_mean, 1, ncd, subject_name,...
            'pCASL - Volume 1 - Average', ...
            folder_statistics, 1, direct_read);
        fig_no = fig_show (fig_no, vol2_mean, 1, ncd, subject_name, ...
            'pCASL - Volume 2 - Average', ...
            folder_statistics, 1, direct_read);
        fig_no = fig_show (fig_no, deltaM .* BrMsk, 'hot', ncd, subject_name, ...
            'pCASL - Difference Map - Average absolute', ...
            folder_statistics, 1, direct_read);
        fig_no = fig_show (fig_no, avg_diff_rel, 'hot', ncd, subject_name, ...
            'pCASL - Difference Map with BrMsk - Average relative', ...
            folder_statistics, 1, direct_read, [0; plot_max_reldiff_labels]);
        fig_no = fig_show (fig_no, mask_nan, 1, ncd, subject_name, ...
            'pCASL - Difference Map with BrMsk - NAN mask', ...
            folder_statistics, 1, direct_read);
        fig_no = fig_show (fig_no, avg_diff_rel_GM, 'hot', ncd, subject_name, ...
            'pCASL - Difference Map with GMmask - Average relative', ...
            folder_statistics, 1, direct_read, [0; plot_max_reldiff_labels]);
        fig_no = fig_show (fig_no, avg_diff_rel_WM, 'hot', ncd, subject_name,...
            'pCASL - Difference Map with WMmask - Average relative', ...
            folder_statistics, 1, direct_read, [0; plot_max_reldiff_labels]);
        fig_no = fig_show (fig_no, BrMsk, 1, ncd, subject_name, 'pCASL - BrMsk', ...
            folder_statistics, 1, direct_read);
        % Check if number of volumes is > 1, otherwise std dev doesn't exist
        if nvols > 1
            fig_no = fig_show (fig_no, vol1_std, 'hot', ncd, subject_name, ...
                'pCASL - Volume 1 - Std t', folder_statistics, 1, direct_read);
            fig_no = fig_show (fig_no, vol2_std, 'hot', ncd, subject_name, ...
                'pCASL - Volume 2 - Std t', folder_statistics, 1, direct_read);
            fig_no = fig_show (fig_no, deltaM_std .* BrMsk, 'hot', ncd, subject_name, ...
                'pCASL - Difference Map - Std t', folder_statistics, 1, direct_read);
        end
        % SNR
        fig_no = fig_show (fig_no, (deltaM ./ deltaM_std) .* BrMsk, 1, ncd, subject_name, ...
            'pCASL - Difference Map - tSNR', folder_statistics, 1, direct_read);
    end


    % ------------------------------------------------------------------------
    % LOAD DELTAM CALCULATED BY THE SCANNER
    % ------------------------------------------------------------------------

    % Safe postproc deltaM
    deltaM_postproc = deltaM;

    % ------------------------------------------------------------------------
    % SLICE STATISTICS
    % ------------------------------------------------------------------------

    % Get median, mean and std values of volume 1 & 2 and delta M
    [vol1_med, vol1_mean, vol1_std, x] = ...
                        statistics_median(vol1_mean .* BrMsk);
    [vol2_med, vol2_mean, vol2_std, x] = ...
                        statistics_median(vol2_mean .* BrMsk);
    [deltaM_med, deltaM_mean, deltaM_std, x] = ...
                        statistics_median(deltaM .* BrMsk);

    % Plot & save statistics
    % Delta M: Mean, Std, Med
    figure(fig_no); clf(fig_no); 
    plot(x, deltaM_mean, 'b', x, deltaM_std, ':r', x, deltaM_med, '--g'); 
    legend('Mean(DeltaM)', 'Std(DeltaM)', 'Median(DeltaM)'); 
    xlabel('Slice number'); ylabel('DeltaM'); 
    title_str = sprintf('SB %s cond %d: DeltaM: Slice selective t Mean, Std & Median - BrMsk applied',...
        subject_name, ncd);
    title(title_str);
    fig_no = fig_no + 1;
    check_folder(fullfile(direct_read, folder_statistics));
    outfile=fullfile(direct_read, folder_statistics, 'DeltaM_Statistics_1.tif');
    saveas(gcf,outfile);
    % Delta M: Errorplot
    figure(fig_no); clf(fig_no); errorbar(deltaM_med, deltaM_std); 
    legend('Mean & Std of DeltaM'); xlabel('Slice number'); ylabel('DeltaM'); 
    title_str = sprintf('SB %s cond %d: DeltaM: Slice selective t Mean & Std - BrMsk applied',...
        subject_name, ncd);
    title(title_str);
    fig_no = fig_no + 1;
    outfile=fullfile(direct_read, folder_statistics, 'DeltaM_Statistics_2.tif');
    saveas(gcf,outfile);
    % SNR
    figure(fig_no); clf(fig_no); plot(x, deltaM_mean ./ deltaM_std); 
    legend('SNR of deltaM'); xlabel('Slice number'); ylabel('SNR'); 
    title_str = sprintf('SB %s cond %d: DeltaM: Slice selective tSNR - BrMsk applied',...
        subject_name, ncd);
    title(title_str);
    fig_no = fig_no + 1;
    outfile=fullfile(direct_read, folder_statistics, 'DeltaM_Statistics_3.tif');
    saveas(gcf,outfile);
    % Vol1&2: Mean, Std, Med
    figure(fig_no); clf(fig_no); 
    plot(x, vol1_med, 'square-b', x, vol1_mean, 'square-g', x, vol1_std, 'square-r',...
         x, vol2_med, '+:b', x, vol2_mean, '+:g', x, vol2_std, '+:r'); 
    legend('Vol1: Median', 'Vol1: Mean', 'Vol1: Std', 'Vol2: Median', ...
        'Vol2: Mean', 'Vol2: Std', 'location', 'EastOutside'); 
    xlabel('Slice number'); ylabel('Intensity');
    title_str = sprintf('SB %s cond %d: Vol1/2: Slice selective t Mean, Std & Median - GMmask applied',...
        subject_name, ncd);
    title(title_str);
    fig_no = fig_no + 1;
    outfile=fullfile(direct_read, folder_statistics, 'Vol_Statistics_1.tif');
    saveas(gcf,outfile);
    % Delta M, Vol1& Vol2: Errorplot
    figure(fig_no); clf(fig_no); errorbar([vol1_mean, vol2_mean], [vol1_std, vol2_std]); 
    legend('Vol1: Mean & Std', 'Vol2: Mean & Std'); xlabel('Slice number'); 
    ylabel('Intensity'); 
    title_str = sprintf('SB %s cond %d: Vol1/2: Slice selective t Mean & Std - masks applied',...
        subject_name, ncd);
    title(title_str);
    fig_no = fig_no + 1;
    outfile=fullfile(direct_read, folder_statistics, 'Vol_Statistics_2.tif');
    saveas(gcf,outfile);


    % ------------------------------------------------------------------------
    % SNR(GM)
    % ------------------------------------------------------------------------

    % Calculate and evaluate SNR of GM difference timecourse
     GMmask = GMseg > 0.2;
     fprintf('\n    Calculating GM SNR: ');
     sigma(1:nx,1:ny,1:nslices)=0;
     for x=1:nx
         fprintf('.');
         for y=1:ny
             for n=1:nslices
                 sigma(x,y,n)=std(difference(x,y,n,:));
             end
         end
     end
     fprintf('\n\n');
     snr=(deltaM./(sigma+eps));

     % Plot
     figure(fig_no); clf(fig_no); hist(snr(GMmask),100);
     fig_no = fig_no + 1;
     textstring = sprintf(' SNR = %3.2f +-%3.2f \n Median: %3.2f\n (GM > = 0.2)',...
     mean(snr(GMmask)), std(snr(GMmask)), median(snr(GMmask)));
     text(2.5,500,textstring,'fontsize',14);
     axis([-1 5 0 max(max(max(hist(snr(GMmask),100))))])
     xlabel('SNR','fontsize',14)
     ylabel('counts','fontsize',14);
     outfile=fullfile(direct_read, folder_statistics, 'SNR_hist.tif');
     saveas(gcf,outfile);
end %%%% get deltaM

%% Show figure
% Automatically plot figure including safe option
function [fig_no] = fig_show (fig_no, data, flag_cb, ncd, subject_name, ...
    title, folder_statistics, flag_savetif, dir_base, caxis_param)
    % Check input
    if nargin < 6
        fprintf('Wrong number of input parameters to show figure')
    elseif nargin == 6
        flag_savetif = 0;
        dir_base = '';
    end
    % Cut off top and bottom slice
    data = data(:,:,2:(end-2));
    % Cancel out NANs
    nan_default = 0;
    mask_nan = isnan(data);
    data(mask_nan) = nan_default;
    nan_voxels_rel = round(sum(sum(sum(mask_nan)))*100/sum(sum(sum(data))));
    % Thresholding image for display
    th = 2^20;
    mask_th = data > th;
    data(mask_th) = th;
    th_voxels_rel = round(sum(sum(sum(mask_th)))*100/sum(sum(sum(data))));
    % Print status
    if th_voxels_rel > 0.5 || nan_voxels_rel > 0.5
        fprintf('        Applied upped limit threshold to %i % and NAN mask to %i % of the voxel.\n',...
            th_voxels_rel, nan_voxels_rel);
    end
    % Show figure
    figure(fig_no); clf(fig_no); newdisp(data);
    % Add colorbar
    if flag_cb ~= 0
        colorbar();
    end
    % Change colormap
    if strcmp(flag_cb, 'hot')
        colormap 'hot';
    elseif strcmp(flag_cb, 'hot_r')
        colormap(flipud(hot))
    end
    % Show title with subject index
    txt_str = sprintf('SB %s cond %d: %s', subject_name, ncd, title);
    text(15,-10, txt_str);
    % caxis
    if nargin == 10
        caxis([caxis_param(1), caxis_param(2)]);
    end
    % Increase figure counter
    fig_no = fig_no + 1;
    % Get dir
    dir = fullfile(dir_base, folder_statistics);
    % Make direct_readory
    if flag_savetif && ~exist(dir, 'dir')
        mkdir(dir);
        fprintf('Creating directory %s\n', dir);
    end
    % Safe tif
    if flag_savetif
        outfile=fullfile(dir, [title '.tif']);
        saveas(gcf,outfile);
    end
end

%% Calculate Statistics of each slice
function [data_med, data_mean, data_std, x] = statistics_median(data)
    % Get data dimensions
    [a,b,c] = size(data);
    % Iterate over all slices
    for i = 1 : c
        % Generate x coordinate
        x(i, 1) = i;
        % Get single slice
        data_i = data(:,:,i);
        % Generate flat data
        data_flat = reshape(data_i, (a*b), 1);
        % Mask zero and negative values
        data_flat_negative_mask = data_flat <= 0;
        data_flat_nonzero = data_flat(~data_flat_negative_mask);
        % Calculate median of non-zero data
        data_med(i, 1) = median(data_flat_nonzero);
        data_mean(i, 1) = mean(data_flat_nonzero);
        data_std(i, 1) = std(data_flat_nonzero);
    end
end

%% Calculate global median
function [median_flat] = median_flat_nonzero(data, flag_nonzero)
    [a,b,c] =  size(data);
    data_flat = reshape(data, (a*b*c), 1);
    if flag_nonzero
        data_flat = nonzeros(data_flat);
    end
    median_flat = median(data_flat);
end

%% Write volume as nii
function write_vol(data, V, filename, dir)
    V.fname=fullfile(dir,filename);
    spm_write_vol(V,data);
end

%% Show GM CBF with/without PVE correction
function calc_GMcbf(direct_read, CBF, GM_CBFcorr, GMseg, WMseg, maxCBF, ...
    fig_no, ncd, folder_statistics)
    % Iterate through GMmask and WMmask
    for i = 1:50
        percentage(i) = 0.02*i-0.01;
        GMmask = GMseg > percentage(i);
        WMmask = WMseg > percentage(i);
        global_GM_CBF(i) = mean((CBF(GMmask)));    
        global_WM_CBF(i) = mean((CBF(WMmask)));
        global_GM_CBFcorr(i) = mean((GM_CBFcorr(GMmask)));
        figure(fig_no); clf; newdisp([GMmask WMmask]); 
        text(15,-10, ['SB' ncd ': Selection ' int2str(2*i) '%']);
        pause(0.1)
    end
    fig_no = fig_no + 1;

    % Save results in text file
    fid = fopen('GlobalCBFValues.txt','a');
        fprintf(fid,'\n%s maxCBF CBF(GM>%3.2f) CBF(WM>%3.2f) [ml/100g/min]\n%s %3.1f %3.1f %3.1f',...
            direct_read, percentage(38), percentage(38), direct_read, maxCBF, ...
            global_GM_CBFcorr(38), global_WM_CBF(38));
    fclose(fid);

    % Value to orient textboxes
    orientation = round(global_GM_CBFcorr(38));
    
    % Plot
    figure(fig_no); clf; plot(percentage, global_GM_CBF, 'c-',...
                    percentage, global_GM_CBFcorr, 'b*',...
                    percentage, global_WM_CBF, 'r+')
               axis([0 1 orientation-20 orientation+20])
    fig_no = fig_no + 1;
    legend1=sprintf('CBF(GM> %3.2f) = %3.1f ml/100g/min\nmaxCBF = %3.1f ml/100g/min',...
                    percentage(38), global_GM_CBFcorr(38), maxCBF);
    text(0.1, orientation -12,legend1,'fontsize',14)
    legend2=sprintf('CBF(WM > %3.2f) = %3.1f ml/100g/min',percentage(38), global_WM_CBF(38));
    text(0.1, orientation -17,legend2,'fontsize',14)
    text(0.5, orientation + 15,'* CBF(GM, PVE corrected)','fontsize',14,'color','b')
    text(0.5, orientation + 12,'- CBF(GM, uncorrected)','fontsize',14,'color','c')
    text(0.5, orientation + 9,'+ CBF(WM, uncorrected)','fontsize',14,'color','r')
    title('Global CBF','fontsize',14)
    xlabel('percentage GM / WM','fontsize',14)
    ylabel('CBF [ml/100 g/min]','fontsize',14)
    outfile = fullfile(direct_read, folder_statistics, 'GlobalCBF(GMpercentage).tif');
    saveas(gcf,outfile);
end