%% Smoothing PD
% - Toolbox for batch processing ASL perfusion based fMRI data.
% - All rights reserved.
% - Ze Wang @ TRC, CFN, Upenn 2004
% - Started in SPM2
% - Using smooth PD implemented by SK 16JUN15

%% Required subscripts

% - SPM12


%% Modifications
% - CP 09APR20
%   + adapt to BIDS & major cleanup

%% Main program
function smooth_M0(VAR, SubjectDir, subject_name, nconditions)
    % ------------------------------------------------------------------------
    % INITIALIZE
    % ------------------------------------------------------------------------
    % print status
    fprintf('Subject %s: Started smoothing the M0 images realigned to pCASL images for all conditions\n',...
        subject_name);

	for ncd = 1:nconditions
        fprintf('Smoothing M0 data subject %s condition %d/%d\n', ...
                                    subject_name, ncd, nconditions);
      	% Select non-normalized Highres CBF-data
      	P= spm_select('FPList', SubjectDir.condition(ncd).pCASL.M0, ...
            '^ro.*\_1.nii$');
      	%take image per image smooth --> Qim is the new image name
        Qim=fullfile(fileparts(P),['s' spm_str_manip(P,'dt')]);
        %now call spm_smooth with kernel defined at VAR
        spm_smooth(P,Qim,VAR.fwhm_smooth_M0);
    end %for ncd = 1:nconditions

    % print status
    fprintf('Finished smoothing of realigned pCASL M0 images for all conditions of subject %s\n',...
                                                              subject_name);

end