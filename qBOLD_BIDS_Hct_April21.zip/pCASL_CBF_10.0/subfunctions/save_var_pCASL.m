%% Save global VAR variables
% - Stephan Kaczmarz
% - 20NOV15

%% Required subscripts


%% Modifications


%% Main program

function save_var_pCASL(VAR, dir_subject)
    % Save variables to file for later reload
    name_global_var = 'Variables.mat';
    path_global_var = fullfile(dir_subject, name_global_var);
    % Delete old VAR
    %delete(path_global_var);
    % Save new VAR
    save(path_global_var, 'VAR');
    % Print status
    fprintf('\nSaved global variables to \n%s %s\n', ...
        dir_subject, name_global_var);
end