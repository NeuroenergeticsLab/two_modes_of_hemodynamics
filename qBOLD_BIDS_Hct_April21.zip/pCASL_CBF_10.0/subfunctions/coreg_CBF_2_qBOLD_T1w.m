%% Coregistration of pCASL & CBF results to high res MPR
% - Original program from Christine Preibisch.
% - Started in SPM2.
% - SK02JUN15: Implemented script.

%% Required subscripts

% - SPM12


%% Modifications

% - SK09JUN15
%   + Debugging of multiple patient processing

% - SK11JUN15
%   + Store coreg CBF-data in Highres folder

% - CP 09APR20
%   + adapt to BIDS & major cleanup
%% Main program


% ------------------------------------------------------------------------
% INITIALIZE
% ------------------------------------------------------------------------
function SubjectDir = coreg_CBF_2_qBOLD_T1w(SubjectDir, subject_name, ...
                                                            nconditions)

    % Print status
    fprintf('Subjects %s: Started coreg for Lowres pCASL CBF to mq-BOLD for all conditions\n',...
        subject_name);

    % Load defaults
    global defaults;
    spm_defaults;
    flags = defaults.coreg;

    % Flags to pass to routine to create resliced images
    % (spm_reslice)
    resFlags = struct(...
        'interp', flags.write.interp,...   % 1: trilinear interpolation
        'wrap', flags.write.wrap,...       % wrapping info (ignore...)
        'mask', flags.write.mask,...       % masking (see spm_reslice)
        'which',1,...                      % write reslice time series 
        'mean',0,...                       % do not write mean image
        'prefix', 'x');                    % do not overwrite existing file


    % ---------------------------------------------------------------------
    % COREGISTRATION
    % ---------------------------------------------------------------------


	% ---------------------------------------------------------------------
	% Set source and target
	% ---------------------------------------------------------------------

	% PG - Tar(G)et image, NEVER CHANGED
 	% PF - Source image, transformed to match PG
 	% PO - (O)ther images, originally realigned to PF and transformed with PF


    % TARGET: T1w MPR coregistered to TE1 of T2 multiecho data
    %         (NOTE: identical copy should be present in each conditions
    %         toplevel directory, so take that of condition 1)
    % get (NOT skull stripped structural from) Structurals
    ncd = 1;
	PG = spm_select('FPList',SubjectDir.condition(ncd).toplevel,'^T1w.nii$');
    PG = PG(1,:);
	VG = spm_vol(PG);

    % SOURCE
    % Use (low resolution) coregistered MPR from pCASL subfolder     
	PF = spm_select('FPList',SubjectDir.condition(ncd).pCASL.T1w,'^rs.*\.nii$');  
	PF = PF(1,:);
	VF = spm_vol(PF);

	% Other images: CBF maps for coregistrations from CBF_lowres folder
    PO = [];
    for ncd = 1:nconditions
        if ncd == 1
            PO = spm_select('FPList',...
                SubjectDir.condition(ncd).pCASL.CBF_Lowres, '^CBF.*\.nii$');
        else
            Ptmp = spm_select('FPList',...
                SubjectDir.condition(ncd).pCASL.CBF_Lowres, '^CBF.*\.nii$');
            PO = char(PO, Ptmp);
        end
    end
        
	% Warning meassage if no CBF were found
	if size(PO,1) == 0
        message_warning = ...
            sprintf('No CBF files found for subject %s. \nPress ok to continue anyways.',...
            subject_name);
        waitfor(warndlg(message_warning));
	end

	%PO = PF; --> this if there are no 'other' images
	if isempty(PO) 
        PO = PF;
    else
        PO = char(PF,PO);
	end

	% ---------------------------------------------------------------------
	% Get coregistration parameters
	% ---------------------------------------------------------------------

	% This method from spm_coreg_ui.m
	% Get coregistration parameters
 	x  = spm_coreg(VG, VF,flags.estimate);

	% Get the transformation to be applied with parameters 'x'
	M  = inv(spm_matrix(x));

	% Transform the mean image
	% Spm_get_space(deblank(PG),M);
	% In MM we put the transformations for the 'other' images
	MM = zeros(4,4,size(PO,1));
	for j=1:size(PO,1)
      	%get the transformation matrix for every image
       	MM(:,:,j) = spm_get_space(deblank(PO(j,:)));
    end
	for j=1:size(PO,1)
       	%write the transformation applied to every image
     	%filename: deblank(PO(j,:))
       	spm_get_space(deblank(PO(j,:)), M*MM(:,:,j));
    end

	% -----------------------------
	% Apply coregistration 
 	% -----------------------------

  	P = char(PG, PO);
   	spm_reslice(P,resFlags);

    % Print status
    fprintf('Finished coreg of Lowres pCASL CBF to qBOLD T1w\n');
end