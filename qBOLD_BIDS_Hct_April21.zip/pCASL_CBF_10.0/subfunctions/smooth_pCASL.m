%% Smoothing pCASL
% - Toolbox for batch processing ASL perfusion based fMRI data.
% - All rights reserved.
% - Ze Wang @ TRC, CFN, Upenn 2004
% - Started in SPM2
% - Using smooth PD implemented by SK 16JUN15

%% Required subscripts

% - SPM12


%% Modifications
% - CP 09APR20
%   + adapt to BIDS & major cleanup

%% Main program
function smooth_pCASL(VAR, SubjectDir, subject_name, nconditions)
    % ------------------------------------------------------------------------
    % INITIALIZE
    % ------------------------------------------------------------------------

    % print status
    fprintf('Smoothing realigned pCASL images for all conditions\n');

	for ncd = 1:nconditions
        fprintf('Smoothing pCASL data subject %s condition %d/%d\n', ...
                                        subject_name, ncd, nconditions);
        % Check if pCASL smoothing shall be performed
        if VAR.flag_smooth_pCASL
            % print status
            fprintf('sub %s condition #%3d/%3d\n',subject_name, ncd, ...
                nconditions);
            fprintf('Smoothing the pCASL label and control images. Kernelsize:%i\n', ...
                VAR.fwhm_smooth_pCASL);

            % Get dir of coreg pCASL
            dir_pCASL = SubjectDir.condition(ncd).pCASL.toplevel;
            dir_pCASL_vol1 = fullfile(dir_pCASL, 'pCASL_realigned_vol1');
            dir_pCASL_vol2 = fullfile(dir_pCASL, 'pCASL_realigned_vol2');
            
          	% Select pCASL data% Get coreg pCASL files
          	P1 = spm_select('FPList',dir_pCASL_vol1,'^rro.*\.nii$'); 
            P2 = spm_select('FPList',dir_pCASL_vol2,'^rro.*\.nii$'); 

            P = strvcat(P1,P2);
            sprintf('There are %u realigned pCASL volumes.\n',size(P,1));

            %perform image per image smooth
            for im=1:size(P,1)
              	%this is actual image
            	Pim=P(im,:);
             	%this the new image name
               	Qim=fullfile(fileparts(Pim),['s' spm_str_manip(Pim,'dt')]);
               	%now call spm_smooth with kernel defined at PAR
               	spm_smooth(Pim,Qim,VAR.fwhm_smooth_pCASL);
            end
        end
    end % for ncd = 1:nconditions 

    % print status
    fprintf('Finished smoothing the fully realigned pCASL subject %s\n',...
        subject_name);

end