%% Coregistration of PD 2 pCASL
% - Original program from Christine Preibisch.
% - Started in SPM2.

%% Required subscripts

% - SPM12


%% Modifications

% - SK22MAI15
%   + Major changes, using PD instead of EPI
%   + Deleted old, unused commented code

% - SK01JUN15
%   + Commented and structurized
%   + Deleted old, unused commented code

% - SK10JUN15
%   + Debugging: Mean file pCASL selection, no other PO files

% - CP 09APR20
%   + adapt to BIDS & major cleanup

%% Main program
function coreg_M0_2_pCASL(SubjectDir, subject_name, nconditions)
                                                            

    % ---------------------------------------------------------------------
    % INITIALIZE
    % ---------------------------------------------------------------------

    % Print status
    fprintf('Started coreg for M0 images to PCASL images for all conditions, subject %s\n',...
                                                            subject_name);

    % Load defaults
    global defaults;
    spm_defaults;
    flags = defaults.coreg;

    % Flags to pass to routine to create resliced images
    % (spm_reslice)
    resFlags = struct(...
        'interp', flags.write.interp,...       % 1: trilinear interpolation
        'wrap', flags.write.wrap,...           % wrapping info (ignore...)
        'mask', flags.write.mask,...           % masking (see spm_reslice)
        'which',1,...                         % write reslice time series 
        'mean',0);                            % do not write mean image

    % ---------------------------------------------------------------------
    % COREGISTRATION
    % ---------------------------------------------------------------------

   	% PG - Tar(G)et image, NEVER CHANGED
   	% PF - Source image, transformed to match PG
	% PO - (O)ther images, originally realigned to PF and transformed with PF

  	% TARGET: Mean pCASL vol 1 (same for all conditions
   	ncd = 1;
   	PG = spm_select('FPList',SubjectDir.condition(ncd).pCASL.toplevel,...
            '^meano.*\_1.nii$');
  	ncd = ncd+1;
 	while isempty(PG) && ncd <= nconditions % look for mean in other 
                                            % condition directories
      	PG = spm_select('FPList',SubjectDir.condition(2).pCASL.toplevel,...
                '^meano.*\_1.nii$');
     	ncd = ncd+1;
    end         
    VG = spm_vol(PG);
    
    %----------------------------------------------------------------------
    % get source files and coregister M0 data (*_1.nii only!) and coregister 
    % to target for all conditions
    %----------------------------------------------------------------------
    for ncd = 1:nconditions% for all conditions

        %SOURCE: M0 for multiple conditions
        PF = spm_select('FPList',SubjectDir.condition(ncd).pCASL.M0,...
            '^o.*\_1.nii$');

        VF = spm_vol(PF);

        % No other images
        PO=PF;

        % -----------------------------------------------------------------
        % Get coregistration parameters
        % -----------------------------------------------------------------

        % This method from spm_coreg_ui.m
        % Get coregistration parameters
        x  = spm_coreg(VG, VF,flags.estimate);

        % Get the transformation to be applied with parameters 'x'
        M  = inv(spm_matrix(x));

        % Transform the mean image
        % spm_get_space(deblank(PG),M);
        % In MM we put the transformations for the 'other' images
        MM = zeros(4,4,size(PO,1));
        for j=1:size(PO,1)
            %get the transformation matrix for every image
            MM(:,:,j) = spm_get_space(deblank(PO(j,:)));
        end
        for j=1:size(PO,1)
            %write the transformation applied to every image
            %filename: deblank(PO(j,:))
                spm_get_space(deblank(PO(j,:)), M*MM(:,:,j));
        end

        % -----------------------------
        % Apply coregistration 
        % -----------------------------

        P = char(PG, PO);
        spm_reslice(P,resFlags);
    end %for ncd = 1:nconditions

fprintf('Finished coreg for M0 images to PCASL images for all conditions, subjects %s\n',...
    subject_name);
end