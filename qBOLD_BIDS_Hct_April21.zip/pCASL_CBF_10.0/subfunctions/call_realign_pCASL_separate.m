%% Realign ASL perfusion based fMRI data separate for each label
% From Stephan Kaczmarz 20OCT15
% Using code from Ze Wang @ TRC, CFN, Upenn 2004. All rights reserved.

%% Required subscripts

% - spm_realign_asl
% - spm_reslice


%% Modifications
% - CP 09APR20
%   + adapt to BIDS & major cleanup

%% Main program
function call_realign_pCASL_separate(SubjectDir, filelist, subject_name,...
                                                            nconditions)
    % ---------------------------------------------------------------------
    % INITIALIZE
    % ---------------------------------------------------------------------

    % ---------------------------------------------------------------------
    % REALIGNMENT OF BOTH LABELS
    % ---------------------------------------------------------------------

    % Display status
    fprintf('Started realigning of raw pCASL images for all subjects\n');

    % Realign vol 1  --> prefix rr
    realign_pCASL_vol1(SubjectDir, subject_name, nconditions); 

    % Realign vol 2 --> prefix r
    realign_pCASL_vol2(SubjectDir, subject_name, nconditions);  

    % Display realignments
    evaluate_realign_pars(SubjectDir, filelist, subject_name, nconditions);

    % ---------------------------------------------------------------------
    % MOVE PCASL FILES
    % ---------------------------------------------------------------------
    
  	% Move unprocessed pCASL files from toplevel pCASL folder 
   	% to '.../pCASL/pCASL_unproc/' folder
   	target_folder_name = 'pCASL_unproc';
  	target_name = 'unprocessed pCASL'; 
   	search_string = '^o.*\.nii$';
   	move_pCASL_files(SubjectDir, subject_name, nconditions,   ...
                 	search_string, target_folder_name, target_name);

 	% Copy realigned volume 1 pCASL files to 
  	% folder '/pCASL/pCASL_realigned_vol1/' 
  	target_folder_name = 'pCASL_realigned_vol1';
   	target_name = 'realigned vol1 pCASL'; 
  	search_string = '^rro.*\.nii$';
  	move_pCASL_files(SubjectDir, subject_name, nconditions,   ...
                   	search_string, target_folder_name, target_name);
   
    % ---------------------------------------------------------------------
    % COREG OF LABEL 1 and 2
    % ---------------------------------------------------------------------
    % --> prefix rr
    coreg_pCASL_volumes(SubjectDir, subject_name, nconditions); 


    % ---------------------------------------------------------------------
    % MOVE PCASL FILES
    % ---------------------------------------------------------------------
 	% Copy realigned volume 2 pCASL files to 
  	% folder '/pCASL/pCASL_realigned_vol1/' 
  	target_folder_name = 'pCASL_realigned_vol2';
   	target_name = 'realigned vol2 pCASL'; 
  	search_string = '^r.*\_2.nii$';
  	move_pCASL_files(SubjectDir, subject_name, nconditions,   ...
                   	search_string, target_folder_name, target_name);
 
    % Display status
    fprintf('Finished realigning of raw pCASL images for all subjects\n');
end
