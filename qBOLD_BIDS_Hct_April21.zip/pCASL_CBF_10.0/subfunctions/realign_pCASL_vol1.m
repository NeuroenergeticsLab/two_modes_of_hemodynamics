%% Realign ASL perfusion based fMRI data for only 1 label
% All rights reserved.
% Ze Wang @ TRC, CFN, Upenn 2004
% Major changes by Stephan Kaczmarz 20OCT15

%% Required subscripts

% - spm_realign_asl
% - spm_reslice


%% Modifications

% - SK26MAI15
%   + Deleted unused, old commented parts
%   + Moved PAR/REC-->Analyze conversion to convert_parrec_2_analyze

% - SK01JUN15
%   + Commented and structurized

% - SK02JUN15
%   + Include mean pCASL image to realignment

% - SK20OCT15
%   + Calcualte only 1 label

% - CP 31AUG18
%   + turn into function

% - CP 09APR20
%   + adapt to BIDS & major cleanup
%% Main program

function realign_pCASL_vol1(SubjectDir, subject_name, nconditions)
    % ---------------------------------------------------------------------
    % INITIALIZE
    % ---------------------------------------------------------------------

    % Display status
    fprintf('Started realigning of time series vol1 pCASL images for all conditions\n');

    % Load defaults
    global defaults;
    spm_defaults;

    % Get realignment defaults
    defs = defaults.realign;

    % Flags to pass to routine to calculate realignment parameters
    % as (possibly) seen at spm_realign_ui,
    % -fwhm = 5 for fMRI
    % -rtm = 0 for fMRI
    % - for this particular data set, we did not perform a second realignment 
    %   to the mean 
    % - coregistration between the reference control and label volume is
    %   also omitted
    reaFlags = struct(...
        'quality', defs.estimate.quality,...  % estimation quality
        'fwhm', 5,...                         % smooth before calculation
        'rtm', 1,...                          % whether to realign to mean
        'PW',''...                            %
        );

    % Flags to pass to routine to create resliced images
    % (spm_reslice)
    resFlags = struct(...
        'interp', 1,...                       % trilinear interpolation
        'wrap', defs.write.wrap,...           % wrapping info (ignore...)
        'mask', defs.write.mask,...           % masking (see spm_reslice)
        'which',2,...                         % write reslice time series for later use
        'mean',1,...                          % do not write mean image
        'prefix', 'rr');                      % use prefix r1


    % ---------------------------------------------------------------------
    % Processing
    % --------------------------------------------------------------------- 
    % Iterate through all conditions and select files for realignment
	for ncd=1:nconditions
     	% Display status
      	fprintf('Realign vol1 of sub %s condition #%3d/%3d\n',...
                                subject_name, ncd, nconditions);      	
       	% Get files in each condtions pCASL directory 
        if ncd == 1
             P = spm_select('ExtFPList',...
                 SubjectDir.condition(ncd).pCASL.toplevel,'^o.*_1.nii$');
        else
            Ptmp = spm_select('ExtFPList',...
                SubjectDir.condition(ncd).pCASL.toplevel,'^o.*_1.nii$');
            P = char(P, Ptmp);
        end       
	end % for ncd =1:nconditions
	% Run realign
	spm_realign_asl(P, reaFlags);

	% Run reslice
	spm_reslice(P, resFlags);
    
    % Display status
    fprintf('Finished realigning of time series pCASL images for all condtions\n');
end
