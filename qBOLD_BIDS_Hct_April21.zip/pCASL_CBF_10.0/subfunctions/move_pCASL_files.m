%% Copy or Move files
% From Stephan Kaczmarz 27OCT15

%% Required subscripts

% - SPM12


%% Modifications
% - CP 09APR20
%   + adapt to BIDS & major cleanup

%% Main program

function move_pCASL_files(SubjectDir, subject_name, nconditions, search_string, ...
                                        target_folder_name, target_name)
    % Iterate through all subjects
    for ncd = 1:nconditions      
        % Print status
        fprintf('Moving %s files of condition %i (subject  %s) \n', ...
                                        target_name, ncd, subject_name);
        % Select source files: nii files
        source_folder = SubjectDir.condition(ncd).pCASL.toplevel;
        filelist = spm_select('FPList', source_folder, search_string);
            % Check filelist
            if size(filelist,1) == 0
                % Print status
                fprintf('Subject %s, condition %d/%d: Moving Aborted as no files were selected!',...
                    subject_name, ncd, nconditions);
            end
            % Set target
            target_folder = fullfile(source_folder, target_folder_name);
            if ~exist(target_folder, 'dir')
                mkdir(target_folder);
                fprintf('Creating directory %s\n', target_folder);
            end
            % Print status
            fprintf('Moving %s files...\n', target_name);
            % Move files
            no_files = size(filelist, 1);
            for i = 1 : no_files
                % print status
                fprintf('.');
                % Get filename
                path_i = strtrim(filelist(i, :));
                [~,filename_i, ext_i] = fileparts(path_i);
                % Get new path
                path_target = fullfile(target_folder, [filename_i ext_i]);
                % Move file
                movefile(path_i, path_target);
            end %i = 1 : no_files
            % Print status
            fprintf('\nMoving of %s files finished.\n', target_name);
    end % for ncd = 1:nconditions
end
