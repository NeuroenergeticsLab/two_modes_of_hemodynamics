%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Split 4D Nifti pCASL data to 3D nifty & extract acqusition parameters
% =========================================================================
%   - CP 07APR2020
% =========================================================================
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [SubjectDir, filelist, pCASL_pars] = Split4Dnifti_pCASL(SubjectDir, ...
                                    filelist, conditions, nconditions, flag)

for ncd = 1:nconditions
	if flag.condition(ncd).pCASL
        % extract acqusition info from json file
        path_json = ...
            dir(fullfile(SubjectDir.condition(ncd).pCASL.toplevel, '*.json'));
        jsoninfo = ...
            jsondecode(fileread(fullfile(path_json.folder, path_json.name)));
        % timing parameters
        pCASL_pars.TE = jsoninfo.EchoTime*1000; % [in ms]
        pCASL_pars.TR = jsoninfo.RepetitionTime*1000; % [in ms]
        path_pCASL = cell2mat(fullfile(SubjectDir.condition(ncd).pCASL.toplevel,...
            filelist.condition(ncd).pCASL.nii));
        V = spm_vol(path_pCASL);   
        dimension = V.dim;
        pCASL_pars.nx = dimension(1);
        pCASL_pars.ny = dimension (2);
        pCASL_pars.nslices = dimension(3);
        pCASL_pars.nframes = length (V);     
        pCASL_pars.time_dyn = ...
            pCASL_pars.TR:pCASL_pars.TR:pCASL_pars.nframes*pCASL_pars.TR; 
        
        % read data
        data = spm_read_vols(V);
        % generate header for single volume (3D) pCASL data
        tV = V(1);
        tV = rmfield(tV,'private');
        
        % for Vendor-specific rescaling of data
        pCASL_pars.Manufacturer = jsoninfo.Manufacturer; 
        if strcmp(pCASL_pars.Manufacturer, 'Philips')
            % According to Dick Kooijman:
            % dicom-tag 0028,1053 (�rescale slope�) can be wrong 
            %       ---> multiply by rescale slope
            % dicon-tag 2005,100E (�scale slope�) should be right
            %       ---> devide by scale slope
            pCASL_pars.RescaleSlope = jsoninfo.PhilipsRescaleSlope;
            pCASL_pars.RescaleIntercept = jsoninfo.PhilipsRescaleIntercept;
            pCASL_pars.ScaleSlope = jsoninfo.PhilipsScaleSlope;
            %CP 10APR20: Scaling of data yields corrupted pCASL time series
            %--> try scaling in calc_cbf
        elseif strcmp(pCASL_pars.Manufacturer, 'Siemens')
            % CP 11APR20: No scaling parameters available im json file
        end
        
        
        % split 4D nifty time series of 3D nifti
        %------------------------------------------------------------------
        % Create M0 directory for PD data
        %------------------------------------------------------------------
        SubjectDir.condition(ncd).pCASL.M0 = fullfile(SubjectDir.output,'qBOLD',...
          	cell2mat(conditions(ncd)),'pCASL','M0');
        check_folder(SubjectDir.condition(ncd).pCASL.M0)
        flag.condition(ncd).PD = 1;        

        [dn,fn,ext] = fileparts(path_pCASL);
        

        %------------------------------------------------------------------
        % Sort data ...
        %------------------------------------------------------------------       
        if strcmp(pCASL_pars.Manufacturer,'Philips')
            % label and control images blocked in 4D input file
            pCASL_pars.LC = flag.pCASL;
            %pCASL_pars.LC = 'blocked';
            nvols = size(data,4)/2; % paired M0
            fctr = 1;               % CAVE: only 1st M0 is PD-weighted!
            for ctr = 1:nvols
                if strcmp(pCASL_pars.LC, 'alternate')
                    if ctr ==1
                        % vol 1
                        tV.fname = sprintf('%s%so_%s_%.3d_1%s',...
                            SubjectDir.condition(ncd).pCASL.M0,filesep,...
                            fn,ctr,ext);
                        filelist.condition(ncd).pCASL.M0(ctr,:) = tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,fctr));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.M0,...
                                sprintf('%s.nii',filename));
                        end
                        fctr = fctr+1;
                        % vol 2
                        tV.fname = sprintf('%s%so_%s_%.3d_2%s',...
                            SubjectDir.condition(ncd).pCASL.M0,filesep,...
                            fn,ctr,ext);
                        filelist.condition(ncd).pCASL.M0(ctr,:) = tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,fctr));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.M0,...
                                sprintf('%s.nii',filename));
                        end                        
                        fctr = fctr+1;  
                    else
                        % vol 1
                        tV.fname = sprintf('%s%so_%s_%.3d_1%s',...
                            dn,filesep,fn,ctr,ext);
                        filelist.condition(ncd).pCASL.vol1(ctr-1,:) = ...
                            tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,fctr));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.toplevel,...
                                sprintf('%s.nii',filename));
                        end                        
                        fctr = fctr+1;
                        % vol 2
                        tV.fname = sprintf('%s%so_%s_%.3d_2%s',...
                            dn,filesep,fn,ctr,ext);
                        filelist.condition(ncd).pCASL.vol2(ctr-1,:) = ...
                            tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,fctr));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.toplevel,...
                                sprintf('%s.nii',filename));
                        end                         
                        fctr = fctr+1;                  
                    end %if ctr ==1
                elseif strcmp(pCASL_pars.LC, 'blocked')
                    if ctr ==1
                        % vol 1
                        tV.fname = sprintf('%s%so_%s_%.3d_1%s',...
                            SubjectDir.condition(ncd).pCASL.M0,filesep,...
                            fn,ctr,ext);
                        filelist.condition(ncd).pCASL.M0(ctr,:) = tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,ctr));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.M0,...
                                sprintf('%s.nii',filename));
                        end                         
                        % vol 2
                        tV.fname = sprintf('%s%so_%s_%.3d_2%s',...
                            SubjectDir.condition(ncd).pCASL.M0,filesep,...
                            fn,ctr,ext);
                        filelist.condition(ncd).pCASL.M0(ctr,:) = tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,ctr+nvols));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.M0,...
                                sprintf('%s.nii',filename));
                        end 
                    else
                        % vol 1
                        tV.fname = sprintf('%s%so_%s_%.3d_1%s',...
                            dn,filesep,fn,ctr,ext);
                        filelist.condition(ncd).pCASL.vol1(ctr-1,:) = ...
                            tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,ctr));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.toplevel,...
                                sprintf('%s.nii',filename));
                        end                         
                        % vol 2
                        tV.fname = sprintf('%s%so_%s_%.3d_2%s',...
                            dn,filesep,fn,ctr,ext);
                        filelist.condition(ncd).pCASL.vol2(ctr-1,:) = ...
                            tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,ctr+nvols));
                         if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.toplevel,...
                                sprintf('%s.nii',filename));
                        end                       
                    end %if ctr ==1
                end % if strcmp(pCASL_pars.LC, 'alternate' vs. 'blocked') 
            end % for ctr=1:nvols
        elseif strcmp(pCASL_pars.Manufacturer,'Siemens')
            % label and control images alternate in 4D input file
            pCASL_pars.LC = flag.pCASL;
            %pCASL_pars.LC = 'alternate';
            % label and control images blocked in 4D input file
            %pCASL_pars.LC = 'blocked';
            nvols = (size(data,4)-1)/2; % unpaired M0
            fctr = 1;
            for ctr = 1:nvols
                if strcmp(pCASL_pars.LC, 'alternate')
                    if ctr ==1
                        % first vol M0!
                        tV.fname = sprintf('%s%so_%s_%.3d_1%s',...
                            SubjectDir.condition(ncd).pCASL.M0,filesep,...
                            fn,ctr,ext);
                        filelist.condition(ncd).pCASL.M0(ctr,:) = tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,fctr));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.M0,...
                                sprintf('%s.nii',filename));
                        end                        
                        fctr = fctr+1; 
                    else
                        % vol 1
                        tV.fname = sprintf('%s%so_%s_%.3d_1%s',...
                            dn,filesep,fn,ctr,ext);
                        filelist.condition(ncd).pCASL.vol1(ctr-1,:) = ...
                            tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,fctr));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.toplevel,...
                                sprintf('%s.nii',filename));
                        end                        
                        fctr = fctr+1;
                        % vol 2
                        tV.fname = sprintf('%s%so_%s_%.3d_2%s',...
                            dn,filesep,fn,ctr,ext);
                        filelist.condition(ncd).pCASL.vol2(ctr-1,:) = ...
                            tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,fctr));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.toplevel,...
                                sprintf('%s.nii',filename));
                        end                        
                        fctr = fctr+1;                  
                    end %if ctr ==1
                elseif strcmp(pCASL_pars.LC, 'blocked')
                    if ctr ==1
                        % first vol M0
                        tV.fname = sprintf('%s%so_%s_%.3d_1%s',...
                            SubjectDir.condition(ncd).pCASL.M0,filesep,...
                            fn,ctr,ext);
                        filelist.condition(ncd).pCASL.M0(ctr,:) = tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,ctr));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.M0,...
                                sprintf('%s.nii',filename));
                        end                        
                    else
                        % vol 1
                        tV.fname = sprintf('%s%so_%s_%.3d_1%s',...
                            dn,filesep,fn,ctr,ext);
                        filelist.condition(ncd).pCASL.vol1(ctr-1,:) = ...
                            tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,ctr));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.toplevel,...
                                sprintf('%s.nii',filename));
                        end                        
                        % vol 2
                        tV.fname = sprintf('%s%so_%s_%.3d_2%s',...
                            dn,filesep,fn,ctr,ext);
                        filelist.condition(ncd).pCASL.vol2(ctr-1,:) = ...
                            tV.fname;
                        fprintf('Writing %s\n',tV.fname);
                        spm_write_vol(tV,data(:,:,:,ctr+nvols));
                        if flag.reset_origin
                            [~,filename,~] = fileparts(tV.fname);
                            reset_origin(SubjectDir.condition(ncd).pCASL.toplevel,...
                                sprintf('%s.nii',filename));
                        end                        
                    end %if ctr ==1
                end % if strcmp(pCASL_pars.LC, 'alternate' vs. 'blocked') 
            end % for ctr=1:nvols           
            
        end % if strcmp(pCASL_pars.Manufacturer, 'Philips' vs.'Siemens')
        fprintf('done.\n');    
	end %if flag.condition(ncd).pCASL
end % for nconditions

end