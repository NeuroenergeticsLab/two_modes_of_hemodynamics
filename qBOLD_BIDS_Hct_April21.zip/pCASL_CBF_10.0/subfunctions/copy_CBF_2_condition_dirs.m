%% Select M0, copy it to 'M0' and copy 'Anatomie' folder to PASL 
% - Original program from Christine Preibisch.
% - Major changes by Stephan Kaczmarz at 21OCT15.


%% Required subscripts

%% Modifications

% - SK01JUN15
%   + Commented

% - SK16OCT15
%   + Using global Variables VAR
%   + Selective PD import casesensitive to pCASL patch data
%
% - CPAPR2020
%   + adapt to BIDS input & multi condition mq-BOLD studies
%   + major revision and cleanup
%
%% Main program
function copy_CBF_2_condition_dirs(SubjectDir, subject_name, nconditions)
    % ------------------------------------------------------------------------
    % INITIALIZE
    % ------------------------------------------------------------------------

    % ------------------------------------------------------------------------
    % COPY
    % ------------------------------------------------------------------------

    % Print status
    fprintf('Subject %s: Started copying CBF parameter maps to toplevel condition folders\n',...
        subject_name);

    % Iterate through all condtions
    for ncd = 1:nconditions
        % Target: Select condition directory
        dir_condition = SubjectDir.condition(ncd).toplevel;       
        % Print status
        fprintf('Condition #%3d/%3d: \n%-5s\n',ncd, nconditions,...
                                                        dir_condition);      
        % Copy CBF maps
        % Source: Select CBF map in CBF_Lowres directory
        CBF_filename_source = fullfile(dir_condition,'CBF_Lowres',...
            'xCBF_3_BRmsk_CSF.nii');
        % Copy file from source to target
        copyfile(CBF_filename_source, dir_condition);
        
    end

    % Print status
    fprintf('Finished copying xCBF_3_BRmsk_CSF to condition folders\n');
end
