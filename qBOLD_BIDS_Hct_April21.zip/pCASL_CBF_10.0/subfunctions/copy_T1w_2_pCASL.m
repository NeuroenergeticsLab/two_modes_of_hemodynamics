%% Select M0, copy it to 'M0' and copy 'Anatomie' folder to PASL 
% - Original program from Christine Preibisch.
% - Major changes by Stephan Kaczmarz at 21OCT15.


%% Required subscripts

 

%% Modifications

% - SK01JUN15
%   + Commented

% - SK16OCT15
%   + Using global Variables VAR
%   + Selective PD import casesensitive to pCASL patch data

% - CP 09APR20
%   + adapt to BIDS & major cleanup

%% Main program
function [SubjectDir, filelist] = copy_T1w_2_pCASL(SubjectDir, filelist, ...
                                             subject_name, conditions)

    % ---------------------------------------------------------------------
    % COPY
    % ---------------------------------------------------------------------
    % Set condition where to copy T1w data
    ncd = 1; 
    
    % Print status
    fprintf('Subject %s: Started copying T1w data & segments to condition %d (%s) pCASL folder\n',...
        subject_name, ncd, conditions(ncd));

        
	% Target:  SubjectDir.condition(ncd).pCASL.toplevel        
	% Create T1w subfolder in pCASL directory
	SubjectDir.condition(ncd).pCASL.T1w = ...
            fullfile(SubjectDir.condition(ncd).pCASL.toplevel, 'T1w');
	% Check folders
	check_folder(SubjectDir.condition(ncd).pCASL.T1w);        

	% Copy T1w: source files are contained in filelist structure
	copyfile(filelist.T1w_nii.anat,SubjectDir.condition(ncd).pCASL.T1w);
	copyfile(filelist.T1w_nii.GM,SubjectDir.condition(ncd).pCASL.T1w);
	copyfile(filelist.T1w_nii.WM,SubjectDir.condition(ncd).pCASL.T1w);
	copyfile(filelist.T1w_nii.CSF,SubjectDir.condition(ncd).pCASL.T1w);
	copyfile(filelist.T1w_nii.BrMsk,SubjectDir.condition(ncd).pCASL.T1w);
 	copyfile(filelist.T1w_nii.BrMsk_CSF,SubjectDir.condition(ncd).pCASL.T1w);        

    % Print status
    fprintf('Finished copying T1w data, segments & masks to pCASL folder\n');
end
