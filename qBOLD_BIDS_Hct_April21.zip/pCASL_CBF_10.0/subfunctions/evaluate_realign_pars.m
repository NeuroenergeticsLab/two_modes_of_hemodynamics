%% pCASL realignment
% - Original version from Toolbox for batch processing ASL perfusion based fMRI data.
% All rights reserved. Ze Wang @ TRC, CFN, Upenn 2004

%% Required subscripts

% - SPM12


%% Modifications

% - SK20OCT15
%   + Analyze multiple realignments


%% Modifications

% - SK16OCT15
%   + separate 

% - CP 09APR20
%   + adapt to BIDS & major cleanup

function evaluate_realign_pars(SubjectDir, filelist, subject_name, nconditions)

% Get number of volumes
    nvols = 0;
    for ncd = 1: nconditions
        nvols = nvols + size(filelist.condition(ncd).pCASL.vol1,1);
    end

    resultstxt = fullfile(SubjectDir.output,'MaxMotionPars_pCASL.txt');

	rp_file = spm_select('FPList',SubjectDir.condition(1).pCASL.toplevel,'^rp.*\.txt$');
	% Get number of realignemnt files
	no_realignments = size(rp_file, 1);

	% Print status
	fprintf('Found %s realignment files\n', num2str(no_realignments));

 	% figure number
  	no_fig = 1;
    
    % Iterate through realignemnt files
	for i = 1 : no_realignments

        % Calculate number of files: #dynamics * 2 labels (- 2 M0 if patched)
        % Only half of the files used if 2 labels are realigned seperately
       	if no_realignments == 2
         	m_division = 2;
        else
         	m_division = 1;
        end

        % # of moco parameters
      	n = 12;
       	% Calculate number of files: 
     	% #dynamics * (2 if not separated label realignments) labels 
     	% (- 2 M0 if patched)
      	m = nvols * 2 / m_division; 
                
      	x = 1:1:m;

      	% Get single rp file
        if i == 1
           	rp_file_i = rp_file(i, :);
      	elseif (i == 2) && (size(rp_file, 1) == 2) 
          	rp_file_i = rp_file(i, :);
        end

    	file_id = fopen(rp_file_i,'r');
         	[RP,~] = fscanf(file_id, '%f', [ n,m ]);
      	fclose(file_id);

      	for j=1:3
          	min_trans(j) = min(RP(j,:));
          	min_trans(j+3) = min(RP(j+6,:));
           	min_rot(j) = min(RP(j+3,:));
          	min_rot(j+3) = min(RP(j+9,:));
         	max_trans(j) = max(RP(j,:));
          	max_trans(j+3) = max(RP(j+6,:));
        	max_rot(j) = max(RP(j+3,:));
          	max_rot(j+3) = max(RP(j+9,:));
        end
     	absmin_trans = min(min_trans);
    	absmax_trans = max(max_trans);
       	absmin_rot = min(min_rot);
     	absmax_rot = max(max_rot);

     	% Plot only in case of more than 1 dynamic
        if m >1
         	figure(no_fig); plot(x,RP(1,:),'r',x,RP(2,:),'b',x,RP(3,:),'g',...
                x,RP(7,:),'r.',x,RP(8,:),'b.',x,RP(9,:),'g.') ;
                axis([1 m absmin_trans absmax_trans])
%                 axis([1 m -3 3])
                titlestr = strcat('Translations ',subject_name);
                title(titlestr);
                str = sprintf('Max. Translation: %4.3f, %4.3f', ...
                    absmin_trans,absmax_trans);
                text(2,absmin_trans*3/4,str,'fontsize',12);
                text(2,absmax_trans*3/4,str,'fontsize',12);
                outfile = fullfile(SubjectDir.output,...
                    ['Translations_pCASL_vol' num2str(i) '.tif']);
                saveas(gcf,outfile)
            no_fig = no_fig + 1;
            figure(no_fig); plot(x,RP(4,:),'r',x,RP(5,:),'b',x,RP(6,:),'g',...
              	x,RP(10,:),'r.',x,RP(11,:),'b.',x,RP(12,:),'g.') ;
                axis([1 m absmin_rot absmax_rot])
%                 axis([1 m -0.03 0.03])
               	titlestr = strcat('Rotations ',subject_name);
                title(titlestr);
              	str = sprintf('Max. Rotation: %4.3f, %4.3f', ...
                            absmin_rot,absmax_rot);
             	text(2,absmin_rot*3/4,str,'fontsize',12);
            	text(2,absmax_rot*3/4,str,'fontsize',12);
               	outfile = fullfile(SubjectDir.output,...
                            ['Rotations_vol' num2str(i) '.tif']);
             	saveas(gcf,outfile)
              	no_fig = no_fig + 1;
        end % if m >1

        file_id = fopen(resultstxt,'a');
    	fprintf(file_id,'%70s %9.4f %9.4f %8.4f %7.4f \n',...
           	SubjectDir.output, absmin_trans,absmax_trans, absmin_rot,absmax_rot);
     	fclose(file_id);
	end %for i = 1 : no_realignments
end % if nvols > 1
