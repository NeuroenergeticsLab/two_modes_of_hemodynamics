%% Get global VAR variables
% - Stephan Kaczmarz
% - 20NOV15

%% Required subscripts


%% Modifications

% - CP 09APR20
%   + adapt to BIDS & major cleanup
%% Main program

function VAR = get_var_pCASL(SubjectDir, filelist)

    % ------------------------------------------------------------------------
    % GET GLOBAL VAR
    % ------------------------------------------------------------------------

    % Print status
    fprintf('    Load Variables  of Subject \n"%s"\n', SubjectDir.output)

    try
        load(filelist.pCASL_VAR,'-mat');
    catch
        % Create warning
        message_warning = ...
            sprintf('Error! No global CBF variables found! Please click ok to continue with default values.');
        waitfor(warndlg(message_warning));
        % Use deltaM manually calculated or by the scanner
        VAR.flag_deltaM_scanner = 0;
        % Force program to use PD instead of M0 in case of patched sequences
        VAR.flag_load_patched_PD = 0;
        % Post label delay set at the scanner [ms].
        VAR.PLD_0 = 1800;
        % Label duration at measurement
        VAR.tao = 1800; % Label duration in ms, following advice from [Alsop15]
        % Set threshold for mask generation by segments
        VAR.th_mask = 0.85;
        % Switch gain correction: PD & pCASL are normalized by gain values. Relevant if dotscaling was deactivated
        VAR.switch_gain_correction = 0;
        % Norm factor application between pCASL & PD. Normalized PD & pCASL by median
        VAR.switch_norm_factor_post = 0;
        % Choose normalization either by PD or first pCASL volume
        %   0: pCASL Norm
        %   1: PD Norm
        VAR.flag_norm_M0 = 1;
        % Choose segments
        %   0: Lowres segments from lowres MPR. MPR was coreg 2 pCASL.
        %   1: Highres segments from highres MPR. Segments were coreg 2 pCASL.
        VAR.flag_highres_segments = 1;
        % Number of omitted slices due to moco artifacts in top/bottom slices.
        VAR.cutoff_slices = 1;
        % CBF map display and cut off threshold for saved data.
        VAR.th_display_CBF = 100;
        VAR.th_cutoff_CBF = 500;
        % Smoothing kernel of M0 smooting
        VAR.fwhm_smooth_M0 = [5];
        % Smoothing kernel of CBF smooting
        VAR.fwhm_smooth_CBF = [5];
        % Gain values
        VAR.gain_pCASL = 1; %CP 09JUL2018: not sure if this makes sense
        % Smoothing pCASL Label and Control before CBF calculation
        VAR.flag_smooth_pCASL = 1;
        VAR.fwhm_smooth_pCASL = [5];
    end
end