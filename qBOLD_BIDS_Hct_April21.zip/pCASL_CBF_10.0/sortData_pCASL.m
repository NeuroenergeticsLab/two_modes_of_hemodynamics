%% Automatic sorting of data (per subject) 
%  for automated qBOLD processing
% - Stephan Kaczmarz 15MAR17
% - CP 28AUG 2018
% - CP 15DEC 2019
%   - Detecting corresponding files and conditions from BIDS convention
%   - Copying files to respective output directories
%--------------------------------------------------------------------------

function [SubjectDir, filelist, pCASL_pars, flag] = sortData_pCASL(...
                                conditions, SubjectDir, filelist, flag)

%determine number of conditions
nconditions = size(conditions,2);   
for ncd = 1:nconditions
    SubjectDir.condition(ncd).toplevel = fullfile(SubjectDir.output,'qBOLD',...
                                            cell2mat(conditions(ncd)));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% Check for ASL; If data exist: unzip and copy
% Also: Check for multiple conditions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%create file list
liste = dir(fullfile(SubjectDir.input,'asl'));
files = {liste.name};   
% Iterate through all foldernames and fill structure with filenames
asl_Fctr_nii(1:nconditions) = 0;
asl_Fctr_json(1:nconditions) = 0;
pd_Fctr_nii(1:nconditions) = 0;
pd_Fctr_json(1:nconditions) = 0;
for i = size(files,2) : -1 : 1
    tmp_str = string(files(i));
    if (regexpi(tmp_str, 'epi_asl')>0) % label-control data   
        for ct = 1:nconditions
            if (regexpi(tmp_str,conditions(ct))>0)
                check_folder(fullfile(SubjectDir.output,'qBOLD',conditions(ct)));
                if (regexpi(tmp_str,'nii.gz')>0)
                    asl_Fctr_nii(ct) = asl_Fctr_nii(ct) +1;
                    filename = cell2mat(files(i));
                    filelist.condition(ct).pCASL.nii(asl_Fctr_nii(ct)) = ...
                    	cellstr(filename(1:end-3));
                    if isfile(fullfile(SubjectDir.input,'asl',files(i)))
                        if asl_Fctr_nii(ct) == 1
                            SubjectDir.condition(ct).pCASL.toplevel = ...
                                fullfile(SubjectDir.output,'qBOLD',...
                            	cell2mat(conditions(ct)),'pCASL');
                            flag.condition(ct).pCASL = 1;
                        end % if asl_Fctr_nii(ct) == 1
                        gunzip(fullfile(SubjectDir.input,'asl',files(i))); 
                        movefile(fullfile(SubjectDir.input,'asl','*.nii'),...
                        	SubjectDir.condition(ct).pCASL.toplevel);   
                    else
                        flag.condition(ct).pCASL = 0;
                    end 
                elseif (regexpi(tmp_str,'json')>0)
                    asl_Fctr_json(ct) = asl_Fctr_json(ct) +1;
                    filelist.condition(ct).pCASL.json(asl_Fctr_json(ct)) = ...
                        files(i);
                    copyfile(cell2mat(fullfile(SubjectDir.input,'asl',files(i))), ...
                    	SubjectDir.condition(ct).pCASL.toplevel); 
                end %if (regexpi(tmp_str,'nii.gz')>0)
            end %if (regexpi(tmp_str,conditions(ct))>0)
        end %for ct = 1:nconditions       
    end %if (regexpi(tmp_str, 'asl')>0)  
end %for i = size(files,2) : -1 : 1

% -------------------------------------------------------------------------
% Prepare 4D BIDS Nifti DATA for pCASL processing
% -------------------------------------------------------------------------
[SubjectDir, filelist, pCASL_pars] = Split4Dnifti_pCASL(SubjectDir, ...
                                 filelist, conditions, nconditions, flag);

    
end